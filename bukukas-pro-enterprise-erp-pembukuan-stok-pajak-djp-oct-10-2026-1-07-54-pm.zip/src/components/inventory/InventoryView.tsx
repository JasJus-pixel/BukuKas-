import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatRupiah, formatNumber, formatDate } from '../../utils/formatters';
import { Modal } from '../common/Modal';
import { 
  Boxes, 
  ArrowLeftRight, 
  ClipboardCheck, 
  Plus, 
  Search, 
  AlertTriangle, 
  CheckCircle2, 
  Truck, 
  PackageCheck,
  RotateCcw
} from 'lucide-react';

export const InventoryView: React.FC = () => {
  const { 
    products, 
    addProduct, 
    branches, 
    activeBranchId, 
    stockTransfers, 
    createStockTransfer, 
    receiveStockTransfer, 
    stockOpnames, 
    createStockOpname,
    currentUser 
  } = useApp();

  const [activeSubTab, setActiveSubTab] = useState<'catalog' | 'transfers' | 'opname'>('catalog');
  const [searchTerm, setSearchTerm] = useState('');

  // Modal States
  const [isNewProductModalOpen, setIsNewProductModalOpen] = useState(false);
  const [isTransferModalOpen, setIsTransferModalOpen] = useState(false);
  const [isOpnameModalOpen, setIsOpnameModalOpen] = useState(false);

  // New Product Form State
  const [newSku, setNewSku] = useState('');
  const [newBarcode, setNewBarcode] = useState('');
  const [newName, setNewName] = useState('');
  const [newCategory, setNewCategory] = useState('Elektronik & IT');
  const [newUnit, setNewUnit] = useState('Unit');
  const [newCostPrice, setNewCostPrice] = useState(1000000);
  const [newSellingPrice, setNewSellingPrice] = useState(1500000);
  const [newMinStock, setNewMinStock] = useState(5);
  const [newInitialStock, setNewInitialStock] = useState(10);

  // Transfer Form State
  const [transferFromBranch, setTransferFromBranch] = useState(branches[0]?.id || 'br-jkt');
  const [transferToBranch, setTransferToBranch] = useState(branches[1]?.id || 'br-sby');
  const [transferProductId, setTransferProductId] = useState(products[0]?.id || '');
  const [transferQty, setTransferQty] = useState(2);
  const [transferNotes, setTransferNotes] = useState('');
  const [transferCourier, setTransferCourier] = useState('Armada Logistik Internal');

  // Opname Form State
  const [opnameBranchId, setOpnameBranchId] = useState(branches[0]?.id || 'br-jkt');
  const [opnameItems, setOpnameItems] = useState(
    products.map(p => ({
      productId: p.id,
      productName: p.name,
      sku: p.sku,
      systemQty: p.stocksByBranch[branches[0]?.id || 'br-jkt'] || 0,
      physicalQty: p.stocksByBranch[branches[0]?.id || 'br-jkt'] || 0,
      costPrice: p.costPrice,
      reason: 'Audit fisik periodik',
    }))
  );

  // Filter products
  const filteredProducts = products.filter(p => {
    const matchesSearch = 
      p.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.sku.toLowerCase().includes(searchTerm.toLowerCase()) ||
      p.barcode.includes(searchTerm);
    return matchesSearch;
  });

  const handleCreateProduct = (e: React.FormEvent) => {
    e.preventDefault();
    if (!newSku || !newName) {
      alert('Mohon isi SKU dan Nama Produk.');
      return;
    }

    const stocksByBranch: Record<string, number> = {};
    branches.forEach(b => {
      stocksByBranch[b.id] = b.id === (activeBranchId === 'all' ? 'br-jkt' : activeBranchId) ? newInitialStock : 0;
    });

    addProduct({
      sku: newSku,
      barcode: newBarcode || `899${Date.now().toString().slice(-10)}`,
      name: newName,
      category: newCategory,
      unit: newUnit,
      costPrice: Number(newCostPrice),
      sellingPrice: Number(newSellingPrice),
      minStockAlert: Number(newMinStock),
      stocksByBranch,
    });

    setIsNewProductModalOpen(false);
    // Reset Form
    setNewSku('');
    setNewBarcode('');
    setNewName('');
  };

  const handleCreateTransfer = (e: React.FormEvent) => {
    e.preventDefault();
    if (transferFromBranch === transferToBranch) {
      alert('Gudang asal dan gudang tujuan tidak boleh sama.');
      return;
    }

    const prd = products.find(p => p.id === transferProductId);
    if (!prd) return;

    const available = prd.stocksByBranch[transferFromBranch] || 0;
    if (transferQty > available) {
      alert(`Stok tidak mencukupi di gudang asal. Tersedia: ${available} unit.`);
      return;
    }

    createStockTransfer({
      date: new Date().toISOString().split('T')[0],
      fromBranchId: transferFromBranch,
      toBranchId: transferToBranch,
      items: [
        {
          productId: prd.id,
          productName: prd.name,
          sku: prd.sku,
          qty: Number(transferQty),
        }
      ],
      notes: transferNotes,
      driverOrCourier: transferCourier,
      trackingNo: `TRF-${Date.now().toString().slice(-6)}`,
    });

    setIsTransferModalOpen(false);
    setTransferNotes('');
  };

  const handleOpenOpnameModal = () => {
    const branchToUse = activeBranchId === 'all' ? 'br-jkt' : activeBranchId;
    setOpnameBranchId(branchToUse);
    setOpnameItems(
      products.map(p => {
        const sysQty = p.stocksByBranch[branchToUse] || 0;
        return {
          productId: p.id,
          productName: p.name,
          sku: p.sku,
          systemQty: sysQty,
          physicalQty: sysQty,
          costPrice: p.costPrice,
          reason: 'Sesuai audit fisik',
        };
      })
    );
    setIsOpnameModalOpen(true);
  };

  const handleOpnamePhysicalChange = (productId: string, val: number) => {
    setOpnameItems(prev => prev.map(item => {
      if (item.productId === productId) {
        return { ...item, physicalQty: val };
      }
      return item;
    }));
  };

  const handleSaveOpname = (e: React.FormEvent) => {
    e.preventDefault();
    let totalDiffVal = 0;
    const finalItems = opnameItems.map(item => {
      const diffQty = item.physicalQty - item.systemQty;
      const diffVal = diffQty * item.costPrice;
      totalDiffVal += diffVal;
      return {
        ...item,
        differenceQty: diffQty,
        differenceValue: diffVal,
      };
    });

    createStockOpname({
      date: new Date().toISOString().split('T')[0],
      branchId: opnameBranchId,
      auditorName: currentUser.name,
      items: finalItems,
      totalDifferenceValue: totalDiffVal,
      notes: `Stok opname gudang oleh ${currentUser.name}`,
    });

    setIsOpnameModalOpen(false);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Manajemen Stok & Logistik Multi-Gudang
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Kontrol persediaan real-time, transfer antar gudang cabang, dan audit stok opname dengan auto-jurnal penyesuaian.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsTransferModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
          >
            <ArrowLeftRight className="w-3.5 h-3.5 text-slate-500" />
            <span>Kirim Mutasi Stok</span>
          </button>
          <button
            onClick={handleOpenOpnameModal}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
          >
            <ClipboardCheck className="w-3.5 h-3.5 text-slate-500" />
            <span>Stok Opname</span>
          </button>
          <button
            onClick={() => setIsNewProductModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors shadow-xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah SKU Baru</span>
          </button>
        </div>
      </div>

      {/* Sub-tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
        <button
          onClick={() => setActiveSubTab('catalog')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeSubTab === 'catalog' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Katalog Stok Persediaan ({products.length} SKU)
        </button>
        <button
          onClick={() => setActiveSubTab('transfers')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeSubTab === 'transfers' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Mutasi Antar Cabang ({stockTransfers.length} Dokumen)
        </button>
        <button
          onClick={() => setActiveSubTab('opname')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeSubTab === 'opname' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Riwayat Stok Opname Fisik ({stockOpnames.length})
        </button>
      </div>

      {/* SUBTAB 1: PRODUCT CATALOG */}
      {activeSubTab === 'catalog' && (
        <div className="space-y-4">
          <div className="flex items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200">
            <div className="relative flex-1 max-w-sm">
              <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Cari SKU, nama produk, barcode..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg w-full focus:ring-1 focus:ring-slate-900 outline-none"
              />
            </div>
            <div className="text-xs text-slate-500">
              Total Nilai Valuasi HPP:{' '}
              <strong className="font-mono text-slate-900">
                {formatRupiah(
                  products.reduce((sum, p) => {
                    const totalQty = Object.values(p.stocksByBranch).reduce((a, b) => a + b, 0);
                    return sum + totalQty * p.costPrice;
                  }, 0)
                )}
              </strong>
            </div>
          </div>

          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                  <tr>
                    <th className="py-3 px-4">SKU / Barcode</th>
                    <th className="py-3 px-4">Nama Produk & Kategori</th>
                    <th className="py-3 px-4 text-right">Harga Beli HPP</th>
                    <th className="py-3 px-4 text-right">Harga Jual</th>
                    <th className="py-3 px-4 text-center">Stok Cabang Jakarta</th>
                    <th className="py-3 px-4 text-center">Stok Cabang Surabaya</th>
                    <th className="py-3 px-4 text-center">Stok Bandung / Bali</th>
                    <th className="py-3 px-4 text-center font-semibold">Total Stok</th>
                    <th className="py-3 px-4 text-center">Status</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {filteredProducts.map((p) => {
                    const totalStock = Object.values(p.stocksByBranch).reduce((a, b) => a + b, 0);
                    const isLow = totalStock <= p.minStockAlert;

                    return (
                      <tr key={p.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono">
                          <div className="font-semibold text-slate-900">{p.sku}</div>
                          <div className="text-[11px] text-slate-400 mt-0.5">{p.barcode}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900">{p.name}</div>
                          <div className="text-[11px] text-slate-500 mt-0.5">{p.category} · Satuan: {p.unit}</div>
                        </td>
                        <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                          {formatRupiah(p.costPrice)}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-slate-900">
                          {formatRupiah(p.sellingPrice)}
                        </td>
                        <td className="py-3 px-4 text-center font-mono tabular-nums text-slate-800">
                          {p.stocksByBranch['br-jkt'] || 0}
                        </td>
                        <td className="py-3 px-4 text-center font-mono tabular-nums text-slate-800">
                          {p.stocksByBranch['br-sby'] || 0}
                        </td>
                        <td className="py-3 px-4 text-center font-mono tabular-nums text-slate-800">
                          {(p.stocksByBranch['br-bdg'] || 0) + (p.stocksByBranch['br-dps'] || 0)}
                        </td>
                        <td className="py-3 px-4 text-center font-mono font-bold tabular-nums text-slate-900">
                          {totalStock} {p.unit}
                        </td>
                        <td className="py-3 px-4 text-center">
                          {isLow ? (
                            <span className="text-amber-800 font-medium text-[11px] flex items-center justify-center">
                              <AlertTriangle className="w-3.5 h-3.5 mr-1 text-amber-700" />
                              Menipis (Min {p.minStockAlert})
                            </span>
                          ) : (
                            <span className="text-emerald-700 font-medium text-[11px] flex items-center justify-center">
                              <CheckCircle2 className="w-3.5 h-3.5 mr-1 text-emerald-600" />
                              Aman
                            </span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 2: STOCK TRANSFERS */}
      {activeSubTab === 'transfers' && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                  <tr>
                    <th className="py-3 px-4">No. Mutasi / Tanggal</th>
                    <th className="py-3 px-4">Rute Pengiriman Antar Gudang</th>
                    <th className="py-3 px-4">Barang Ditransfer</th>
                    <th className="py-3 px-4">Kurir & Pelacakan</th>
                    <th className="py-3 px-4 text-center">Status Mutasi</th>
                    <th className="py-3 px-4 text-center">Aksi Konfirmasi</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {stockTransfers.map((trf) => {
                    const fromBr = branches.find(b => b.id === trf.fromBranchId);
                    const toBr = branches.find(b => b.id === trf.toBranchId);

                    return (
                      <tr key={trf.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4">
                          <div className="font-semibold text-slate-900 font-mono">{trf.transferNumber}</div>
                          <div className="text-[11px] text-slate-500 mt-0.5">{formatDate(trf.date)}</div>
                        </td>
                        <td className="py-3 px-4">
                          <div className="flex items-center gap-1 font-medium text-slate-900">
                            <span>{fromBr?.name || trf.fromBranchId}</span>
                            <span className="text-slate-400">→</span>
                            <span className="text-slate-900">{toBr?.name || trf.toBranchId}</span>
                          </div>
                          {trf.notes && <div className="text-[11px] text-slate-500 mt-0.5 italic">{trf.notes}</div>}
                        </td>
                        <td className="py-3 px-4">
                          {trf.items.map((item, idx) => (
                            <div key={idx} className="font-medium text-slate-800">
                              {item.productName} (<span className="font-mono">{item.qty} unit</span>)
                            </div>
                          ))}
                        </td>
                        <td className="py-3 px-4">
                          <div className="text-slate-800">{trf.driverOrCourier || '-'}</div>
                          {trf.trackingNo && (
                            <div className="text-[11px] font-mono text-slate-500 mt-0.5">Resi: {trf.trackingNo}</div>
                          )}
                        </td>
                        <td className="py-3 px-4 text-center">
                          {trf.status === 'received' ? (
                            <span className="text-emerald-700 font-semibold text-[11px] flex items-center justify-center">
                              <PackageCheck className="w-3.5 h-3.5 mr-1" />
                              Diterima di Tujuan
                            </span>
                          ) : (
                            <span className="text-amber-800 font-semibold text-[11px] flex items-center justify-center">
                              <Truck className="w-3.5 h-3.5 mr-1 text-amber-700" />
                              Dalam Perjalanan (In-Transit)
                            </span>
                          )}
                        </td>
                        <td className="py-3 px-4 text-center">
                          {trf.status === 'in_transit' ? (
                            <button
                              onClick={() => {
                                if (window.confirm('Konfirmasi bahwa barang telah sampai dan diperiksa di gudang tujuan? Stok tujuan akan otomatis ditambahkan.')) {
                                  receiveStockTransfer(trf.id);
                                }
                              }}
                              className="px-3 py-1.5 bg-slate-900 hover:bg-slate-800 text-white font-medium text-xs rounded-md shadow-xs transition-colors cursor-pointer"
                            >
                              Terima Barang
                            </button>
                          ) : (
                            <span className="text-slate-400 text-[11px]">{trf.receivedAt || 'Selesai'}</span>
                          )}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* SUBTAB 3: STOCK OPNAME */}
      {activeSubTab === 'opname' && (
        <div className="space-y-4">
          <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-xs">
                <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                  <tr>
                    <th className="py-3 px-4">No. Dokumen Opname</th>
                    <th className="py-3 px-4">Tanggal & Lokasi Cabang</th>
                    <th className="py-3 px-4">Auditor / Pemeriksa</th>
                    <th className="py-3 px-4">Ringkasan Selisih Fisik</th>
                    <th className="py-3 px-4 text-right">Nilai Selisih Rupiah</th>
                    <th className="py-3 px-4 text-center">Jurnal Penyesuaian</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-100">
                  {stockOpnames.map((opn) => {
                    const br = branches.find(b => b.id === opn.branchId);

                    return (
                      <tr key={opn.id} className="hover:bg-slate-50/70">
                        <td className="py-3 px-4 font-mono font-semibold text-slate-900">
                          {opn.opnameNumber}
                        </td>
                        <td className="py-3 px-4">
                          <div className="font-medium text-slate-800">{br?.name || opn.branchId}</div>
                          <div className="text-[11px] text-slate-500 mt-0.5">{formatDate(opn.date)}</div>
                        </td>
                        <td className="py-3 px-4 text-slate-700">
                          {opn.auditorName}
                        </td>
                        <td className="py-3 px-4">
                          {opn.items.map((item, idx) => (
                            <div key={idx} className="text-[11px] text-slate-700">
                              • {item.productName}: Fisik <strong className="font-mono">{item.physicalQty}</strong> (Sistem: <span className="font-mono">{item.systemQty}</span>)
                              {item.differenceQty !== 0 && (
                                <span className={`ml-1 font-semibold ${item.differenceQty < 0 ? 'text-amber-800' : 'text-emerald-700'}`}>
                                  [Selisih: {item.differenceQty}]
                                </span>
                              )}
                            </div>
                          ))}
                        </td>
                        <td className="py-3 px-4 text-right font-mono font-bold tabular-nums">
                          <span className={opn.totalDifferenceValue < 0 ? 'text-amber-800' : 'text-emerald-700'}>
                            {formatRupiah(opn.totalDifferenceValue)}
                          </span>
                        </td>
                        <td className="py-3 px-4 text-center">
                          <span className="text-emerald-700 font-semibold text-[11px] flex items-center justify-center">
                            <CheckCircle2 className="w-3.5 h-3.5 mr-1" />
                            Diposting ke Buku Besar
                          </span>
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}

      {/* Modal Tambah Produk Baru */}
      <Modal
        isOpen={isNewProductModalOpen}
        onClose={() => setIsNewProductModalOpen(false)}
        title="Tambah Produk & SKU Baru ke Gudang"
        subtitle="Daftarkan SKU untuk pelacakan persediaan stok dan pencatatan transaksi."
      >
        <form onSubmit={handleCreateProduct} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Kode SKU Produk</label>
              <input
                type="text"
                placeholder="misal: ELC-SPK-07"
                value={newSku}
                onChange={(e) => setNewSku(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Barcode / EAN-13</label>
              <input
                type="text"
                placeholder="8991234500707"
                value={newBarcode}
                onChange={(e) => setNewBarcode(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Nama Produk Lengkap</label>
            <input
              type="text"
              placeholder="misal: Speaker Wireless Conference Hub Poly"
              value={newName}
              onChange={(e) => setNewName(e.target.value)}
              required
              className="w-full border border-slate-300 rounded-lg p-2 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Kategori Barang</label>
              <select
                value={newCategory}
                onChange={(e) => setNewCategory(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              >
                <option value="Elektronik & IT">Elektronik & IT</option>
                <option value="Perlengkapan Kantor">Perlengkapan Kantor</option>
                <option value="Peralatan Mesin">Peralatan Mesin</option>
                <option value="Aksesoris & Lainnya">Aksesoris & Lainnya</option>
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Satuan Ukuran</label>
              <select
                value={newUnit}
                onChange={(e) => setNewUnit(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              >
                <option value="Unit">Unit</option>
                <option value="Pcs">Pcs</option>
                <option value="Box">Box</option>
                <option value="Set">Set</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Harga Beli HPP (Rp)</label>
              <input
                type="number"
                value={newCostPrice}
                onChange={(e) => setNewCostPrice(Number(e.target.value))}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Harga Jual Standar (Rp)</label>
              <input
                type="number"
                value={newSellingPrice}
                onChange={(e) => setNewSellingPrice(Number(e.target.value))}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono font-semibold outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Batas Minimum Stok (Alert)</label>
              <input
                type="number"
                value={newMinStock}
                onChange={(e) => setNewMinStock(Number(e.target.value))}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Stok Awal di Cabang Aktif</label>
              <input
                type="number"
                value={newInitialStock}
                onChange={(e) => setNewInitialStock(Number(e.target.value))}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none"
              />
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsNewProductModalOpen(false)}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Simpan Produk
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal Mutasi Antar Gudang */}
      <Modal
        isOpen={isTransferModalOpen}
        onClose={() => setIsTransferModalOpen(false)}
        title="Kirim Mutasi Stok Antar Cabang"
        subtitle="Memindahkan stok fisik dari gudang asal ke gudang cabang tujuan."
      >
        <form onSubmit={handleCreateTransfer} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Gudang Asal (Pengirim)</label>
              <select
                value={transferFromBranch}
                onChange={(e) => setTransferFromBranch(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              >
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Gudang Tujuan (Penerima)</label>
              <select
                value={transferToBranch}
                onChange={(e) => setTransferToBranch(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              >
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div className="col-span-2">
              <label className="block font-medium text-slate-700 mb-1">Pilih Produk yang Dikirim</label>
              <select
                value={transferProductId}
                onChange={(e) => setTransferProductId(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              >
                {products.map(p => (
                  <option key={p.id} value={p.id}>
                    {p.name} (Tersedia: {p.stocksByBranch[transferFromBranch] || 0} unit)
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Jumlah (Qty)</label>
              <input
                type="number"
                min={1}
                value={transferQty}
                onChange={(e) => setTransferQty(Number(e.target.value))}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none text-center"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Supir / Ekspedisi Logistik</label>
            <input
              type="text"
              placeholder="contoh: Mobil Box Hilux Surabaya (Driver: Pak Bambang)"
              value={transferCourier}
              onChange={(e) => setTransferCourier(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-2 outline-none"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Catatan Pengiriman</label>
            <input
              type="text"
              placeholder="Keperluan pemenuhan pesanan customer / stok pameran"
              value={transferNotes}
              onChange={(e) => setTransferNotes(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-2 outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsTransferModalOpen(false)}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Kirim Mutasi Stok
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal Stok Opname */}
      <Modal
        isOpen={isOpnameModalOpen}
        onClose={() => setIsOpnameModalOpen(false)}
        title="Formulir Audit Stok Opname Fisik"
        subtitle="Perbandingan stok fisik aktual vs sistem. Selisih akan otomatis dihitung dan dibuatkan Jurnal Penyesuaian."
        maxWidth="3xl"
      >
        <form onSubmit={handleSaveOpname} className="space-y-4 text-xs">
          <div>
            <label className="block font-medium text-slate-700 mb-1">Pilih Lokasi Gudang Cabang</label>
            <select
              value={opnameBranchId}
              onChange={(e) => {
                const bId = e.target.value;
                setOpnameBranchId(bId);
                setOpnameItems(products.map(p => {
                  const sys = p.stocksByBranch[bId] || 0;
                  return {
                    productId: p.id,
                    productName: p.name,
                    sku: p.sku,
                    systemQty: sys,
                    physicalQty: sys,
                    costPrice: p.costPrice,
                    reason: 'Audit fisik periodik',
                  };
                }));
              }}
              className="w-full border border-slate-300 rounded-lg p-2 outline-none"
            >
              {branches.map(b => (
                <option key={b.id} value={b.id}>{b.name} ({b.city})</option>
              ))}
            </select>
          </div>

          <div className="border border-slate-200 rounded-lg overflow-hidden max-h-72 overflow-y-auto">
            <table className="w-full text-left">
              <thead className="bg-slate-50 text-slate-500 sticky top-0 border-b border-slate-200">
                <tr>
                  <th className="p-2.5">Produk</th>
                  <th className="p-2.5 text-center w-24">Stok Sistem</th>
                  <th className="p-2.5 text-center w-28">Stok Fisik Aktual</th>
                  <th className="p-2.5 text-right w-24">Selisih Qty</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {opnameItems.map((item) => {
                  const diff = item.physicalQty - item.systemQty;

                  return (
                    <tr key={item.productId} className="hover:bg-slate-50/50">
                      <td className="p-2.5">
                        <div className="font-semibold text-slate-900">{item.productName}</div>
                        <div className="font-mono text-[11px] text-slate-400">{item.sku}</div>
                      </td>
                      <td className="p-2.5 text-center font-mono font-medium text-slate-700">
                        {item.systemQty}
                      </td>
                      <td className="p-2.5 text-center">
                        <input
                          type="number"
                          value={item.physicalQty}
                          onChange={(e) => handleOpnamePhysicalChange(item.productId, Number(e.target.value))}
                          className="w-20 border border-slate-300 rounded p-1 text-center font-mono font-bold outline-none"
                        />
                      </td>
                      <td className="p-2.5 text-right font-mono font-bold">
                        <span className={diff === 0 ? 'text-slate-400' : diff < 0 ? 'text-amber-800' : 'text-emerald-700'}>
                          {diff > 0 ? `+${diff}` : diff}
                        </span>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-600">
            ℹ️ Sistem akan mengupdate stok tercatat ke angka fisik dan membuat jurnal penyesuaian:
            <br />
            <strong>Debit/Kredit Beban Penyesuaian Selisih Stok</strong> vs <strong>Persediaan Barang Dagang</strong>.
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsOpnameModalOpen(false)}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Posting Penyesuaian Stok Opname
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
