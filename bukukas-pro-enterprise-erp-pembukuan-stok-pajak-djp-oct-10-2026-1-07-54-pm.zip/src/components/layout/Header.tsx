import React from 'react';
import { useApp } from '../../context/AppContext';
import { Building2, UserCheck, Plus, RefreshCw } from 'lucide-react';
import { Role } from '../../types/accounting';

interface HeaderProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  onOpenNewTransaction: () => void;
}

export const Header: React.FC<HeaderProps> = ({
  activeTab,
  setActiveTab,
  onOpenNewTransaction,
}) => {
  const { 
    branches, 
    activeBranchId, 
    setActiveBranchId, 
    currentUser, 
    switchUserRole, 
    resetToDefaultData 
  } = useApp();

  const roleLabels: Record<Role, string> = {
    super_admin: 'Super Admin',
    branch_manager: 'Manajer Cabang',
    accountant: 'Akuntan / Finance',
    cashier_staff: 'Kasir & Gudang',
  };

  return (
    <header className="bg-white border-b border-slate-200 sticky top-0 z-40">
      {/* Top Bar Contract: Zone 1 (Wordmark) — Zone 2 (4-5 Nav Links) — Zone 3 (1 Primary Action) */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 flex items-center justify-between gap-8 h-16">
        {/* Zone 1: Single text element wordmark */}
        <a 
          href="#dashboard" 
          onClick={(e) => { e.preventDefault(); setActiveTab('dashboard'); }}
          className="text-lg font-bold tracking-tight text-slate-900 whitespace-nowrap shrink-0 hover:text-slate-700 transition-colors"
        >
          BukuKas Pro
        </a>

        {/* Zone 2: 4-5 concise single-line text links */}
        <nav className="hidden md:flex items-center gap-6 text-sm font-medium text-slate-600">
          <button
            onClick={() => setActiveTab('dashboard')}
            className={`whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors ${
              activeTab === 'dashboard' ? 'text-slate-950 font-semibold' : ''
            }`}
          >
            Dashboard
          </button>
          <button
            onClick={() => setActiveTab('transactions')}
            className={`whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors ${
              activeTab === 'transactions' ? 'text-slate-950 font-semibold' : ''
            }`}
          >
            Transaksi
          </button>
          <button
            onClick={() => setActiveTab('reports')}
            className={`whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors ${
              activeTab === 'reports' ? 'text-slate-950 font-semibold' : ''
            }`}
          >
            Laporan
          </button>
          <button
            onClick={() => setActiveTab('inventory')}
            className={`whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors ${
              activeTab === 'inventory' ? 'text-slate-950 font-semibold' : ''
            }`}
          >
            Stok & Aset
          </button>
          <button
            onClick={() => setActiveTab('tax')}
            className={`whitespace-nowrap shrink-0 hover:text-slate-900 transition-colors ${
              activeTab === 'tax' ? 'text-slate-950 font-semibold' : ''
            }`}
          >
            e-Faktur DJP
          </button>
        </nav>

        {/* Zone 3: 1 primary action */}
        <div className="flex items-center gap-3 shrink-0">
          <button
            onClick={onOpenNewTransaction}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors whitespace-nowrap shrink-0 shadow-xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Catat Transaksi</span>
          </button>
        </div>
      </div>

      {/* Enterprise Context Workspace Bar: Branch Switcher & Multi-User Role Simulator */}
      <div className="border-t border-slate-100 bg-slate-50/80 px-4 sm:px-6 py-2 text-xs">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-3">
          <div className="flex items-center gap-3 flex-wrap">
            {/* Multi-Cabang Selector */}
            <div className="flex items-center gap-1.5 text-slate-600">
              <Building2 className="w-3.5 h-3.5 text-slate-500" />
              <span className="font-medium text-slate-700">Cabang Usaha:</span>
              <select
                value={activeBranchId}
                onChange={(e) => setActiveBranchId(e.target.value)}
                className="bg-white border border-slate-300 text-slate-900 text-xs rounded-md px-2.5 py-1 focus:ring-1 focus:ring-slate-900 focus:border-slate-900 outline-none cursor-pointer"
              >
                <option value="all">Semua Cabang (Konsolidasi Holding)</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>
                    {b.code} - {b.name} ({b.city})
                  </option>
                ))}
              </select>
            </div>

            <span className="text-slate-300 hidden sm:inline" aria-hidden="true">·</span>

            {/* Role-Based Access Control Switcher */}
            <div className="flex items-center gap-1.5 text-slate-600">
              <UserCheck className="w-3.5 h-3.5 text-slate-500" />
              <span className="font-medium text-slate-700">Peran Aktif:</span>
              <select
                value={currentUser.role}
                onChange={(e) => switchUserRole(e.target.value as Role)}
                className="bg-white border border-slate-300 text-slate-900 text-xs rounded-md px-2.5 py-1 focus:ring-1 focus:ring-slate-900 focus:border-slate-900 outline-none cursor-pointer"
              >
                <option value="super_admin">Super Admin / Pemilik</option>
                <option value="accountant">Akuntan / Finance</option>
                <option value="branch_manager">Manajer Cabang</option>
                <option value="cashier_staff">Kasir & Staf Gudang</option>
              </select>
              <span className="text-slate-500 hidden md:inline">({currentUser.name})</span>
            </div>
          </div>

          <div className="flex items-center gap-3 ml-auto text-slate-500">
            <span className="hidden lg:inline text-slate-600">
              NITKU Terhubung: <span className="font-mono text-slate-900">0100456789012000000001</span>
            </span>
            <button
              onClick={() => {
                if (window.confirm('Reset data sistem ke saldo awal simulasi?')) {
                  resetToDefaultData();
                }
              }}
              title="Reset data ke default"
              className="flex items-center gap-1 hover:text-slate-900 transition-colors cursor-pointer text-xs"
            >
              <RefreshCw className="w-3 h-3" />
              <span>Reset Data</span>
            </button>
          </div>
        </div>
      </div>
    </header>
  );
};
