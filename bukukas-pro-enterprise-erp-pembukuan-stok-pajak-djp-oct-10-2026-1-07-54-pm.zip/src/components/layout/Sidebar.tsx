import React from 'react';
import { 
  LayoutDashboard, 
  ReceiptText, 
  BookOpen, 
  FileSpreadsheet, 
  Boxes, 
  ShieldCheck, 
  Building2, 
  TrendingUp,
  Cpu
} from 'lucide-react';

interface SidebarProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
  unbalancedJournalsCount?: number;
  lowStockCount?: number;
  pendingEfakturCount?: number;
}

export const Sidebar: React.FC<SidebarProps> = ({
  activeTab,
  setActiveTab,
  lowStockCount = 0,
  pendingEfakturCount = 0,
}) => {
  const menuItems = [
    {
      id: 'dashboard',
      label: 'Dashboard & Analitik',
      description: 'KPI bisnis, arus kas, margin laba',
      icon: LayoutDashboard,
    },
    {
      id: 'transactions',
      label: 'Transaksi Harian',
      description: 'Penjualan, pembelian, beban',
      icon: ReceiptText,
    },
    {
      id: 'journal',
      label: 'Jurnal Umum Otomatis',
      description: 'Double-entry, saldo seimbang',
      icon: BookOpen,
    },
    {
      id: 'reports',
      label: 'Laporan Keuangan',
      description: 'Laba rugi, neraca, arus kas',
      icon: FileSpreadsheet,
    },
    {
      id: 'inventory',
      label: 'Manajemen Stok & Mutasi',
      description: 'Multi-gudang & stok opname',
      icon: Boxes,
      badge: lowStockCount > 0 ? `${lowStockCount} menipis` : undefined,
    },
    {
      id: 'assets',
      label: 'Aset Tetap & Depresiasi',
      description: 'Jadwal penyusutan garis lurus',
      icon: Cpu,
    },
    {
      id: 'tax',
      label: 'Perpajakan & e-Faktur DJP',
      description: 'PPN, PPh, integrasi PJAP resmi',
      icon: ShieldCheck,
      badge: pendingEfakturCount > 0 ? `${pendingEfakturCount} draf` : undefined,
    },
    {
      id: 'branches',
      label: 'Multi-Cabang & Hak Akses',
      description: 'Kelola cabang & role RBAC',
      icon: Building2,
    },
  ];

  return (
    <aside className="w-64 bg-white border-r border-slate-200 shrink-0 hidden md:block py-6 flex flex-col justify-between">
      <div className="space-y-1 px-3">
        <div className="px-3 pb-3">
          <div className="flex items-center gap-2 text-xs font-semibold uppercase tracking-wider text-slate-400">
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Modul Enterprise</span>
          </div>
        </div>

        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          return (
            <button
              key={item.id}
              onClick={() => setActiveTab(item.id)}
              className={`w-full flex items-start gap-3 px-3 py-2.5 rounded-lg text-left transition-colors cursor-pointer group ${
                isActive
                  ? 'bg-slate-900 text-white'
                  : 'text-slate-600 hover:bg-slate-100 hover:text-slate-900'
              }`}
            >
              <Icon className={`w-4 h-4 mt-0.5 shrink-0 ${isActive ? 'text-white' : 'text-slate-500 group-hover:text-slate-800'}`} />
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between">
                  <span className={`text-xs font-semibold truncate ${isActive ? 'text-white' : 'text-slate-800'}`}>
                    {item.label}
                  </span>
                  {item.badge && (
                    <span className={`text-[10px] ml-1.5 tabular-nums ${isActive ? 'text-slate-300' : 'text-amber-600'}`}>
                      {item.badge}
                    </span>
                  )}
                </div>
                <p className={`text-[11px] truncate mt-0.5 ${isActive ? 'text-slate-300' : 'text-slate-400'}`}>
                  {item.description}
                </p>
              </div>
            </button>
          );
        })}
      </div>

      {/* Compliance Information Footer */}
      <div className="px-6 pt-4 border-t border-slate-100 mt-6 text-[11px] text-slate-400">
        <div className="text-slate-600 font-medium">Standar Akuntansi & Pajak</div>
        <div className="mt-1 space-y-0.5">
          <p>• SAK Entitas Privat (SAK EP)</p>
          <p>• UU HPP No. 7/2021 (PPN 11%)</p>
          <p>• PJAP DJP SK KEP-224/PJ/2020</p>
        </div>
      </div>
    </aside>
  );
};
