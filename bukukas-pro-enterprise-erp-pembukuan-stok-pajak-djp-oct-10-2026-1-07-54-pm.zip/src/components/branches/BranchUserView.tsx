import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { Modal } from '../common/Modal';
import { 
  Building2, 
  Users, 
  Plus, 
  ShieldCheck, 
  Check, 
  X, 
  MapPin, 
  Phone, 
  Briefcase 
} from 'lucide-react';
import { Role } from '../../types/accounting';

export const BranchUserView: React.FC = () => {
  const { 
    branches, 
    addBranch, 
    users, 
    addUser, 
    currentUser, 
    switchUserRole 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'branches' | 'users' | 'matrix'>('branches');
  const [isBranchModalOpen, setIsBranchModalOpen] = useState(false);
  const [isUserModalOpen, setIsUserModalOpen] = useState(false);

  // New Branch Form
  const [branchCode, setBranchCode] = useState('');
  const [branchName, setBranchName] = useState('');
  const [branchCity, setBranchCity] = useState('');
  const [branchAddress, setBranchAddress] = useState('');
  const [branchPhone, setBranchPhone] = useState('');
  const [branchManager, setBranchManager] = useState('');
  const [branchNitku, setBranchNitku] = useState('');

  // New User Form
  const [userName, setUserName] = useState('');
  const [userEmail, setUserEmail] = useState('');
  const [userRole, setUserRole] = useState<Role>('branch_manager');
  const [userBranchId, setUserBranchId] = useState(branches[0]?.id || 'br-jkt');
  const [userPhone, setUserPhone] = useState('');

  const handleCreateBranch = (e: React.FormEvent) => {
    e.preventDefault();
    if (!branchCode || !branchName) return;

    addBranch({
      code: branchCode,
      name: branchName,
      address: branchAddress,
      city: branchCity,
      phone: branchPhone,
      nitku: branchNitku || `010045678901200000000${branches.length + 1}`,
      managerName: branchManager,
      isActive: true,
    });

    setIsBranchModalOpen(false);
    setBranchCode('');
    setBranchName('');
  };

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    if (!userName || !userEmail) return;

    addUser({
      name: userName,
      email: userEmail,
      role: userRole,
      branchId: userBranchId,
      phone: userPhone,
      isActive: true,
    });

    setIsUserModalOpen(false);
    setUserName('');
    setUserEmail('');
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Multi-Cabang Usaha & Tata Kelola Pengguna (RBAC)
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Pengelolaan desentralisasi cabang usaha terintegrasi NITKU dan pembagian hak akses sesuai posisi jabatan.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={() => setIsBranchModalOpen(true)}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-900 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
          >
            <Building2 className="w-3.5 h-3.5 text-slate-500" />
            <span>Tambah Cabang</span>
          </button>
          <button
            onClick={() => setIsUserModalOpen(true)}
            className="flex items-center gap-1.5 px-4 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah Akun Pengguna</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
        <button
          onClick={() => setActiveTab('branches')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeTab === 'branches' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Daftar Cabang Usaha ({branches.length})
        </button>
        <button
          onClick={() => setActiveTab('users')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeTab === 'users' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Daftar Pengguna & Akses ({users.length})
        </button>
        <button
          onClick={() => setActiveTab('matrix')}
          className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
            activeTab === 'matrix' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Matriks Hak Akses Jabatan (RBAC Matrix)
        </button>
      </div>

      {/* TAB 1: BRANCHES */}
      {activeTab === 'branches' && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {branches.map((b) => (
            <div key={b.id} className="bg-white p-5 rounded-xl border border-slate-200 space-y-3 shadow-2xs">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className="w-8 h-8 rounded-lg bg-slate-100 flex items-center justify-center font-bold text-xs text-slate-800">
                    {b.code.split('-')[0]}
                  </div>
                  <div>
                    <h3 className="font-bold text-slate-900 text-sm">{b.name}</h3>
                    <div className="text-[11px] text-slate-500 font-mono">Kode Cabang: {b.code}</div>
                  </div>
                </div>
                <span className="text-emerald-700 font-medium text-xs">Aktif Operasional</span>
              </div>

              <div className="text-xs space-y-1.5 text-slate-600 pt-1">
                <div className="flex items-start gap-2">
                  <MapPin className="w-3.5 h-3.5 text-slate-400 mt-0.5 shrink-0" />
                  <span>{b.address}, {b.city}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Phone className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>{b.phone}</span>
                </div>
                <div className="flex items-center gap-2">
                  <Briefcase className="w-3.5 h-3.5 text-slate-400 shrink-0" />
                  <span>Kepala Cabang: <strong>{b.managerName}</strong></span>
                </div>
              </div>

              <div className="pt-2 border-t border-slate-100 flex items-center justify-between text-[11px]">
                <span className="text-slate-500">NITKU DJP Terdaftar:</span>
                <span className="font-mono text-slate-800 font-semibold">{b.nitku}</span>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* TAB 2: USERS */}
      {activeTab === 'users' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
                <tr>
                  <th className="py-3 px-4">Nama Pengguna & Email</th>
                  <th className="py-3 px-4">Posisi / Peran (Role)</th>
                  <th className="py-3 px-4">Penugasan Cabang</th>
                  <th className="py-3 px-4">Kontak Telepon</th>
                  <th className="py-3 px-4 text-center">Status</th>
                  <th className="py-3 px-4 text-center">Aksi Simulasi</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {users.map((u) => {
                  const branch = branches.find(b => b.id === u.branchId);
                  const isCurrent = currentUser.email === u.email;

                  return (
                    <tr key={u.id} className="hover:bg-slate-50/70">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900">{u.name}</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">{u.email}</div>
                      </td>
                      <td className="py-3 px-4">
                        <span className="font-medium text-slate-800 capitalize">
                          {u.role === 'super_admin' ? 'Super Admin / Pemilik' :
                           u.role === 'accountant' ? 'Akuntan / Finance' :
                           u.role === 'branch_manager' ? 'Manajer Cabang' : 'Kasir & Gudang'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-slate-700">
                        {u.branchId === 'all' ? 'Seluruh Cabang (Nasional)' : (branch?.name || u.branchId)}
                      </td>
                      <td className="py-3 px-4 font-mono text-slate-600">
                        {u.phone || '-'}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className="text-emerald-700 font-medium text-[11px]">Aktif</span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        {isCurrent ? (
                          <span className="text-xs font-semibold text-slate-900 bg-slate-100 px-2.5 py-1 rounded-md">
                            Sedang Digunakan
                          </span>
                        ) : (
                          <button
                            onClick={() => switchUserRole(u.role)}
                            className="px-2.5 py-1 text-[11px] text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                          >
                            Masuk Sebagai Ini
                          </button>
                        )}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* TAB 3: RBAC MATRIX */}
      {activeTab === 'matrix' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
          <div className="p-4 bg-slate-50 border-b border-slate-200">
            <h2 className="text-sm font-bold text-slate-900">Matriks Hak Akses Pengguna (Role-Based Access Control)</h2>
            <p className="text-xs text-slate-500">Pembatasan wewenang modul berdasarkan pemisahan tugas (Segregation of Duties).</p>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-600 font-semibold border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4">Fitur / Modul Sistem</th>
                  <th className="py-3 px-4 text-center">Super Admin</th>
                  <th className="py-3 px-4 text-center">Manajer Cabang</th>
                  <th className="py-3 px-4 text-center">Akuntan / Finance</th>
                  <th className="py-3 px-4 text-center">Kasir & Gudang</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100 text-center">
                <tr>
                  <td className="py-3 px-4 text-left font-medium text-slate-900">Dashboard & Analisis Holding</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-700">Cabang Sendiri</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-300">-</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-left font-medium text-slate-900">Catat Penjualan & Kasir POS</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-left font-medium text-slate-900">Jurnal Umum & Jurnal Penyesuaian Manual</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-400">Lihat Saja</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-300">-</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-left font-medium text-slate-900">Laporan Keuangan Resmi (Laba Rugi, Neraca)</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-700">Cabang Sendiri</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-300">-</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-left font-medium text-slate-900">Mutasi Antar Gudang & Terima Stok</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-400">Lihat Saja</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-left font-medium text-slate-900">Stok Opname & Penyesuaian Fisik</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Approval</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Audit</td>
                  <td className="py-3 px-4 text-slate-700">Input Fisik</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-left font-medium text-slate-900">Penyusutan Aset Tetap</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-300">-</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-300">-</td>
                </tr>
                <tr>
                  <td className="py-3 px-4 text-left font-medium text-slate-900">Modul e-Faktur & Integrasi PJAP DJP</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-300">-</td>
                  <td className="py-3 px-4 text-emerald-700 font-bold">Penuh</td>
                  <td className="py-3 px-4 text-slate-300">-</td>
                </tr>
              </tbody>
            </table>
          </div>
        </div>
      )}

      {/* Modal Tambah Cabang */}
      <Modal
        isOpen={isBranchModalOpen}
        onClose={() => setIsBranchModalOpen(false)}
        title="Buka Kantor / Gudang Cabang Baru"
        subtitle="Mendaftarkan entitas cabang usaha baru ke dalam sistem holding konsolidasi."
      >
        <form onSubmit={handleCreateBranch} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Kode Cabang</label>
              <input
                type="text"
                placeholder="misal: SMG-05"
                value={branchCode}
                onChange={(e) => setBranchCode(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Kota Lokasi</label>
              <input
                type="text"
                placeholder="Semarang"
                value={branchCity}
                onChange={(e) => setBranchCity(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Nama Cabang Lengkap</label>
            <input
              type="text"
              placeholder="Cabang & DC Semarang Kawasan Candi"
              value={branchName}
              onChange={(e) => setBranchName(e.target.value)}
              required
              className="w-full border border-slate-300 rounded-lg p-2 outline-none"
            />
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Alamat Gudang / Kantor</label>
            <input
              type="text"
              placeholder="Kawasan Industri Candi Blok XI No. 8"
              value={branchAddress}
              onChange={(e) => setBranchAddress(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-2 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Nomor Telepon</label>
              <input
                type="text"
                placeholder="024-7628819"
                value={branchPhone}
                onChange={(e) => setBranchPhone(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Kepala Cabang / PIC</label>
              <input
                type="text"
                placeholder="Agus Santoso"
                value={branchManager}
                onChange={(e) => setBranchManager(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              />
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">NITKU DJP (Format 22 Digit Baru)</label>
            <input
              type="text"
              placeholder="0100456789012000000005"
              value={branchNitku}
              onChange={(e) => setBranchNitku(e.target.value)}
              className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none"
            />
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsBranchModalOpen(false)}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Simpan Cabang Baru
            </button>
          </div>
        </form>
      </Modal>

      {/* Modal Tambah User */}
      <Modal
        isOpen={isUserModalOpen}
        onClose={() => setIsUserModalOpen(false)}
        title="Tambah Akun Pengguna & Hak Akses"
        subtitle="Berikan kredensial dan hak akses sesuai tanggung jawab operasional."
      >
        <form onSubmit={handleCreateUser} className="space-y-4 text-xs">
          <div>
            <label className="block font-medium text-slate-700 mb-1">Nama Lengkap</label>
            <input
              type="text"
              placeholder="Rudi Hermawan, S.E."
              value={userName}
              onChange={(e) => setUserName(e.target.value)}
              required
              className="w-full border border-slate-300 rounded-lg p-2 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Email Perusahaan</label>
              <input
                type="email"
                placeholder="rudi.finance@bukukaspro.id"
                value={userEmail}
                onChange={(e) => setUserEmail(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Nomor WhatsApp / HP</label>
              <input
                type="text"
                placeholder="0812-3456-7890"
                value={userPhone}
                onChange={(e) => setUserPhone(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Posisi / Hak Akses (Role)</label>
              <select
                value={userRole}
                onChange={(e) => setUserRole(e.target.value as any)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              >
                <option value="branch_manager">Manajer Cabang</option>
                <option value="accountant">Akuntan / Finance</option>
                <option value="cashier_staff">Kasir & Staf Gudang</option>
                <option value="super_admin">Super Admin / Pemilik</option>
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Penugasan Cabang</label>
              <select
                value={userBranchId}
                onChange={(e) => setUserBranchId(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              >
                <option value="all">Seluruh Cabang (Konsolidasi)</option>
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsUserModalOpen(false)}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Buat Akun Pengguna
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
