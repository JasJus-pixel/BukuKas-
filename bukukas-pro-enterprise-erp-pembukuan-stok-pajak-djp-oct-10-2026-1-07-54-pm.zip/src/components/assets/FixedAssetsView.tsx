import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatRupiah, formatDate } from '../../utils/formatters';
import { Modal } from '../common/Modal';
import { 
  Plus, 
  RotateCw, 
  CheckCircle2, 
  Cpu, 
  TrendingDown, 
  DollarSign,
  AlertCircle
} from 'lucide-react';

export const FixedAssetsView: React.FC = () => {
  const { 
    fixedAssets, 
    addFixedAsset, 
    runMonthlyDepreciation, 
    branches, 
    activeBranchId 
  } = useApp();

  const [isModalOpen, setIsModalOpen] = useState(false);
  const [depreciationSuccessMsg, setDepreciationSuccessMsg] = useState<string | null>(null);

  // New Asset Form
  const [assetCode, setAssetCode] = useState('');
  const [assetName, setAssetName] = useState('');
  const [category, setCategory] = useState<'Kendaraan' | 'Peralatan Kantor' | 'Komputer & IT' | 'Gedung & Bangunan' | 'Mesin Produksi'>('Kendaraan');
  const [branchId, setBranchId] = useState(branches[0]?.id || 'br-jkt');
  const [purchaseDate, setPurchaseDate] = useState(new Date().toISOString().split('T')[0]);
  const [cost, setCost] = useState(50000000);
  const [salvage, setSalvage] = useState(5000000);
  const [usefulYears, setUsefulYears] = useState(4);

  const filteredAssets = fixedAssets.filter(a => {
    return activeBranchId === 'all' || a.branchId === activeBranchId;
  });

  const totalCost = filteredAssets.reduce((sum, a) => sum + a.acquisitionCost, 0);
  const totalAccumulated = filteredAssets.reduce((sum, a) => sum + a.accumulatedDepreciation, 0);
  const totalBookValue = filteredAssets.reduce((sum, a) => sum + a.bookValue, 0);
  const totalMonthlyDepreciation = filteredAssets.reduce((sum, a) => sum + a.monthlyDepreciation, 0);

  const handleRunDepreciation = () => {
    const res = runMonthlyDepreciation();
    setDepreciationSuccessMsg(
      `Penyusutan bulanan sebesar ${formatRupiah(res.totalDepreciated)} berhasil dijalankan dan dijurnal ke ${res.journalNumber}.`
    );
    setTimeout(() => setDepreciationSuccessMsg(null), 6000);
  };

  const handleAddAsset = (e: React.FormEvent) => {
    e.preventDefault();
    if (!assetCode || !assetName) {
      alert('Mohon isi kode dan nama aset.');
      return;
    }

    addFixedAsset({
      code: assetCode,
      name: assetName,
      category,
      branchId,
      purchaseDate,
      acquisitionCost: Number(cost),
      salvageValue: Number(salvage),
      usefulLifeYears: Number(usefulYears),
      depreciationMethod: 'straight_line',
      status: 'active',
    });

    setIsModalOpen(false);
    setAssetCode('');
    setAssetName('');
  };

  return (
    <div className="space-y-6">
      {/* Header & Action */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Pencatatan Aset Tetap & Depresiasi Otomatis
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Manajemen aktiva tetap dengan metode penyusutan Garis Lurus (Straight-Line) dan posting otomatis ke buku besar.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleRunDepreciation}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-slate-900 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
          >
            <RotateCw className="w-3.5 h-3.5" />
            <span>Jalankan Penyusutan Bulanan</span>
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors shadow-xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Tambah Aset Tetap</span>
          </button>
        </div>
      </div>

      {depreciationSuccessMsg && (
        <div className="p-3 bg-emerald-50 border border-emerald-200 text-emerald-800 text-xs rounded-lg flex items-center gap-2">
          <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0" />
          <span>{depreciationSuccessMsg}</span>
        </div>
      )}

      {/* KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-xl">
          <span className="text-xs text-slate-500">Harga Perolehan Aset</span>
          <div className="text-lg font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {formatRupiah(totalCost)}
          </div>
        </div>
        <div className="p-4 bg-white border border-slate-200 rounded-xl">
          <span className="text-xs text-slate-500">Akumulasi Penyusutan</span>
          <div className="text-lg font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {formatRupiah(totalAccumulated)}
          </div>
        </div>
        <div className="p-4 bg-white border border-slate-200 rounded-xl">
          <span className="text-xs text-slate-500">Total Nilai Buku Bersih</span>
          <div className="text-lg font-bold font-mono text-emerald-700 mt-1 tabular-nums">
            {formatRupiah(totalBookValue)}
          </div>
        </div>
        <div className="p-4 bg-white border border-slate-200 rounded-xl">
          <span className="text-xs text-slate-500">Beban Penyusutan / Bulan</span>
          <div className="text-lg font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {formatRupiah(totalMonthlyDepreciation)}
          </div>
        </div>
      </div>

      {/* Assets Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4">Kode / Nama Aset Tetap</th>
                <th className="py-3 px-4">Kategori & Cabang</th>
                <th className="py-3 px-4">Tgl Perolehan</th>
                <th className="py-3 px-4 text-right">Harga Perolehan</th>
                <th className="py-3 px-4 text-center">Masa Manfaat</th>
                <th className="py-3 px-4 text-right">Penyusutan / Bulan</th>
                <th className="py-3 px-4 text-right">Akumulasi Penyusutan</th>
                <th className="py-3 px-4 text-right font-semibold">Nilai Buku Saat Ini</th>
                <th className="py-3 px-4 text-center">Status</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filteredAssets.map((asset) => {
                const branch = branches.find(b => b.id === asset.branchId);

                return (
                  <tr key={asset.id} className="hover:bg-slate-50/70">
                    <td className="py-3 px-4">
                      <div className="font-semibold text-slate-900">{asset.name}</div>
                      <div className="text-[11px] font-mono text-slate-400 mt-0.5">{asset.code}</div>
                    </td>
                    <td className="py-3 px-4">
                      <div className="font-medium text-slate-800">{asset.category}</div>
                      <div className="text-[11px] text-slate-500 mt-0.5">{branch?.name || asset.branchId}</div>
                    </td>
                    <td className="py-3 px-4 text-slate-600">
                      {formatDate(asset.purchaseDate)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-900">
                      {formatRupiah(asset.acquisitionCost)}
                    </td>
                    <td className="py-3 px-4 text-center font-mono">
                      {asset.usefulLifeYears} Tahun
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {formatRupiah(asset.monthlyDepreciation)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                      {formatRupiah(asset.accumulatedDepreciation)}
                    </td>
                    <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-emerald-700">
                      {formatRupiah(asset.bookValue)}
                    </td>
                    <td className="py-3 px-4 text-center">
                      <span className="text-emerald-700 font-medium text-[11px] capitalize">
                        {asset.status === 'active' ? 'Aktif' : 'Disposed'}
                      </span>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal Tambah Aset Tetap */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Pencatatan Aset Tetap Baru"
        subtitle="Mencatat perolehan aktiva berwujud untuk jadwal depresiasi otomatis."
      >
        <form onSubmit={handleAddAsset} className="space-y-4 text-xs">
          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Kode Identifikasi Aset</label>
              <input
                type="text"
                placeholder="AST-KND-05"
                value={assetCode}
                onChange={(e) => setAssetCode(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Kategori Aset Tetap</label>
              <select
                value={category}
                onChange={(e) => setCategory(e.target.value as any)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              >
                <option value="Kendaraan">Kendaraan</option>
                <option value="Komputer & IT">Komputer & IT</option>
                <option value="Peralatan Kantor">Peralatan Kantor</option>
                <option value="Mesin Produksi">Mesin Produksi</option>
                <option value="Gedung & Bangunan">Gedung & Bangunan</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Nama Aset Tetap</label>
            <input
              type="text"
              placeholder="contoh: Toyota Avanza 1.5 G Veloz Operasional Sales"
              value={assetName}
              onChange={(e) => setAssetName(e.target.value)}
              required
              className="w-full border border-slate-300 rounded-lg p-2 outline-none"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Cabang Penempatan</label>
              <select
                value={branchId}
                onChange={(e) => setBranchId(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              >
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Tanggal Pembelian / Perolehan</label>
              <input
                type="date"
                value={purchaseDate}
                onChange={(e) => setPurchaseDate(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-lg p-2 outline-none"
              />
            </div>
          </div>

          <div className="grid grid-cols-3 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Harga Perolehan (Rp)</label>
              <input
                type="number"
                value={cost}
                onChange={(e) => setCost(Number(e.target.value))}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Nilai Residu Sisa (Rp)</label>
              <input
                type="number"
                value={salvage}
                onChange={(e) => setSalvage(Number(e.target.value))}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Masa Manfaat (Tahun)</label>
              <input
                type="number"
                min={1}
                max={30}
                value={usefulYears}
                onChange={(e) => setUsefulYears(Number(e.target.value))}
                required
                className="w-full border border-slate-300 rounded-lg p-2 font-mono outline-none text-center"
              />
            </div>
          </div>

          <div className="p-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-600">
            Perkiraan Depresiasi Bulanan Garis Lurus:{' '}
            <strong className="font-mono text-slate-900">
              {formatRupiah(Math.round((cost - salvage) / (usefulYears * 12)))} / bulan
            </strong>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Simpan Aset Tetap
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
