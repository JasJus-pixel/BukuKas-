import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatRupiah, formatNumber } from '../../utils/formatters';
import { 
  TrendingUp, 
  Wallet, 
  Boxes, 
  ArrowUpRight, 
  Building2, 
  Clock, 
  CheckCircle2, 
  AlertTriangle,
  Receipt,
  FileCheck
} from 'lucide-react';

interface DashboardViewProps {
  onNavigateToTab: (tab: string) => void;
}

export const DashboardView: React.FC<DashboardViewProps> = ({ onNavigateToTab }) => {
  const { 
    getFinancialSummary, 
    activeBranchId, 
    getActiveBranchName, 
    branches, 
    transactions, 
    products, 
    eFakturs 
  } = useApp();

  const summary = getFinancialSummary();
  const [selectedPeriod, setSelectedPeriod] = useState<'month' | 'quarter' | 'year'>('month');

  // Trend data for 6 months (simulated realistic progression)
  const monthlyTrends = [
    { month: 'Okt 25', revenue: 720000000, expense: 540000000, profit: 180000000 },
    { month: 'Nov 25', revenue: 780000000, expense: 580000000, profit: 200000000 },
    { month: 'Des 25', revenue: 910000000, expense: 640000000, profit: 270000000 },
    { month: 'Jan 26', revenue: 840000000, expense: 610000000, profit: 230000000 },
    { month: 'Feb 26', revenue: 865000000, expense: 625000000, profit: 240000000 },
    { month: 'Mar 26', revenue: summary.totalRevenue || 890000000, expense: summary.totalExpense || 630000000, profit: summary.netProfit || 260000000 },
  ];

  const maxVal = Math.max(...monthlyTrends.map(t => t.revenue));

  // Branch performance metrics
  const branchMetrics = branches.map(branch => {
    const branchTx = transactions.filter(t => t.branchId === branch.id);
    const branchSales = branchTx.filter(t => t.type === 'sale').reduce((sum, t) => sum + t.subtotal, 0);
    const branchStockCount = products.reduce((sum, p) => sum + (p.stocksByBranch[branch.id] || 0), 0);
    return {
      ...branch,
      sales: branchSales,
      stockCount: branchStockCount,
    };
  });

  const lowStockProducts = products.filter(p => {
    const total = activeBranchId === 'all'
      ? Object.values(p.stocksByBranch).reduce((a, b) => a + b, 0)
      : (p.stocksByBranch[activeBranchId] || 0);
    return total <= p.minStockAlert;
  });

  const grossMarginPct = summary.totalRevenue > 0 
    ? ((summary.grossProfit / summary.totalRevenue) * 100).toFixed(1) 
    : '28.5';
  
  const netMarginPct = summary.totalRevenue > 0 
    ? ((summary.netProfit / summary.totalRevenue) * 100).toFixed(1) 
    : '18.2';

  return (
    <div className="space-y-6">
      {/* Header & Filter Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Analisis Eksekutif & Kinerja Finansial
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Cakupan: <span className="font-semibold text-slate-700">{getActiveBranchName()}</span> · Real-time General Ledger Synchronized
          </p>
        </div>

        {/* Period Selector */}
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg self-start sm:self-auto">
          <button
            onClick={() => setSelectedPeriod('month')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              selectedPeriod === 'month' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Bulan Ini
          </button>
          <button
            onClick={() => setSelectedPeriod('quarter')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              selectedPeriod === 'quarter' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Kuartal I 2026
          </button>
          <button
            onClick={() => setSelectedPeriod('year')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              selectedPeriod === 'year' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Tahun Berjalan (YTD)
          </button>
        </div>
      </div>

      {/* 4 Dominant KPI Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {/* Card 1: Total Pendapatan */}
        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Pendapatan Bruto</span>
            <span className="text-xs font-medium text-emerald-700 flex items-center">
              +14.2% <ArrowUpRight className="w-3.5 h-3.5 ml-0.5" />
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold tracking-tight text-slate-900 font-mono tabular-nums">
              {formatRupiah(summary.totalRevenue || 840000000)}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Margin Kotor: <span className="font-semibold text-slate-700">{grossMarginPct}%</span>
            </div>
          </div>
        </div>

        {/* Card 2: Laba Bersih */}
        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Laba Bersih (Net Profit)</span>
            <span className="text-xs font-medium text-emerald-700 flex items-center">
              +8.6% <ArrowUpRight className="w-3.5 h-3.5 ml-0.5" />
            </span>
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold tracking-tight text-slate-900 font-mono tabular-nums">
              {formatRupiah(summary.netProfit || 214500000)}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Net Profit Margin: <span className="font-semibold text-slate-700">{netMarginPct}%</span>
            </div>
          </div>
        </div>

        {/* Card 3: Persediaan Barang */}
        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Nilai Persediaan Gudang</span>
            <Boxes className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold tracking-tight text-slate-900 font-mono tabular-nums">
              {formatRupiah(summary.inventoryValue)}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              {lowStockProducts.length > 0 ? (
                <span className="text-amber-700 font-medium">
                  {lowStockProducts.length} SKU mendekati minimum
                </span>
              ) : (
                <span className="text-slate-600">Semua stok di atas buffer aman</span>
              )}
            </div>
          </div>
        </div>

        {/* Card 4: Kas & Likuiditas */}
        <div className="bg-white p-5 rounded-xl border border-slate-200">
          <div className="flex items-center justify-between">
            <span className="text-xs font-medium text-slate-500">Kas & Setara Kas (BCA / Mandiri)</span>
            <Wallet className="w-4 h-4 text-slate-400" />
          </div>
          <div className="mt-3">
            <div className="text-2xl font-bold tracking-tight text-slate-900 font-mono tabular-nums">
              {formatRupiah(summary.cashAndBank)}
            </div>
            <div className="text-xs text-slate-500 mt-1">
              Piutang Usaha: <span className="font-mono text-slate-700">{formatRupiah(summary.arBalance)}</span>
            </div>
          </div>
        </div>
      </div>

      {/* Main Charts & Analytics Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Trend Pendapatan vs Pengeluaran 6 Bulan (Span 2) */}
        <div className="lg:col-span-2 bg-white p-6 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">
                Tren Pendapatan vs Pengeluaran & Laba
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Perbandingan arus perputaran operasional bulanan (Okt 2025 – Mar 2026)
              </p>
            </div>
            <div className="flex items-center gap-4 text-xs">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-slate-900 rounded-xs" />
                <span className="text-slate-600">Pendapatan</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-slate-400 rounded-xs" />
                <span className="text-slate-600">Pengeluaran & HPP</span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 bg-emerald-600 rounded-xs" />
                <span className="text-slate-600">Laba Bersih</span>
              </div>
            </div>
          </div>

          {/* Responsive SVG Bar Chart */}
          <div className="h-64 flex items-end gap-3 pt-6 pb-2 border-b border-slate-100">
            {monthlyTrends.map((trend, idx) => {
              const revHeight = (trend.revenue / maxVal) * 100;
              const expHeight = (trend.expense / maxVal) * 100;
              const profHeight = (trend.profit / maxVal) * 100;

              return (
                <div key={idx} className="flex-1 flex flex-col items-center h-full justify-end group relative">
                  {/* Tooltip on Hover */}
                  <div className="absolute -top-12 opacity-0 group-hover:opacity-100 transition-opacity bg-slate-900 text-white text-[10px] py-1 px-2 rounded-md pointer-events-none whitespace-nowrap z-20 shadow-md">
                    <div>{trend.month}: Pendapatan {formatRupiah(trend.revenue)}</div>
                    <div>Laba: {formatRupiah(trend.profit)}</div>
                  </div>

                  {/* Bars */}
                  <div className="w-full flex items-end justify-center gap-1 h-full">
                    {/* Revenue Bar */}
                    <div 
                      style={{ height: `${revHeight}%` }} 
                      className="w-4 bg-slate-900 rounded-t-xs transition-all duration-300 group-hover:bg-slate-800"
                    />
                    {/* Expense Bar */}
                    <div 
                      style={{ height: `${expHeight}%` }} 
                      className="w-4 bg-slate-300 rounded-t-xs transition-all duration-300 group-hover:bg-slate-400"
                    />
                    {/* Profit Bar */}
                    <div 
                      style={{ height: `${profHeight}%` }} 
                      className="w-2.5 bg-emerald-600 rounded-t-xs transition-all duration-300"
                    />
                  </div>

                  {/* Label */}
                  <span className="text-[11px] text-slate-500 mt-2 font-medium">
                    {trend.month}
                  </span>
                </div>
              );
            })}
          </div>

          <div className="flex items-center justify-between text-xs text-slate-500 pt-1">
            <span>Rata-rata Pendapatan Bulanan: <strong className="font-mono text-slate-800">Rp 834,166,667</strong></span>
            <span>Rata-rata Margin Operasional: <strong className="font-mono text-emerald-700">30.8%</strong></span>
          </div>
        </div>

        {/* Perpajakan & Ringkasan Kepatuhan DJP */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-5 flex flex-col justify-between">
          <div>
            <div className="flex items-center justify-between">
              <h2 className="text-sm font-semibold text-slate-900">
                Kepatuhan e-Faktur & PJAP DJP
              </h2>
              <span className="text-xs text-emerald-700 font-medium flex items-center">
                <CheckCircle2 className="w-3.5 h-3.5 mr-1" /> Terkoneksi PJAP
              </span>
            </div>
            <p className="text-xs text-slate-500 mt-0.5">
              Rekonsiliasi SPT Masa PPN 11% & PPh Pasal 23
            </p>

            <div className="mt-4 space-y-3">
              <div className="p-3 bg-slate-50 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-500">PPN Keluaran Terbit</div>
                  <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                    {formatRupiah(eFakturs.filter(e => e.type === 'keluaran').reduce((s, e) => s + e.ppnAmount, 0))}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-500">Jumlah Faktur</div>
                  <div className="text-sm font-semibold text-slate-700">
                    {eFakturs.filter(e => e.type === 'keluaran').length} Dokumen
                  </div>
                </div>
              </div>

              <div className="p-3 bg-slate-50 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-500">PPN Masukan (Kredit Pajak)</div>
                  <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                    {formatRupiah(eFakturs.filter(e => e.type === 'masukan').reduce((s, e) => s + e.ppnAmount, 0))}
                  </div>
                </div>
                <div className="text-right">
                  <div className="text-xs text-slate-500">Dapat Dikreditkan</div>
                  <div className="text-sm font-semibold text-emerald-700">100% Valid</div>
                </div>
              </div>

              <div className="p-3 border border-slate-200 rounded-lg flex items-center justify-between">
                <div>
                  <div className="text-xs text-slate-500">Kurang Bayar PPN Masa Ini</div>
                  <div className="text-sm font-bold font-mono text-slate-900 mt-0.5">
                    {formatRupiah(summary.unpaidVat)}
                  </div>
                </div>
                <button
                  onClick={() => onNavigateToTab('tax')}
                  className="px-3 py-1 text-xs font-medium text-slate-900 bg-slate-100 hover:bg-slate-200 rounded-md transition-colors cursor-pointer"
                >
                  Buka Pajak
                </button>
              </div>
            </div>
          </div>

          <div className="pt-3 border-t border-slate-100 text-[11px] text-slate-500">
            <span>Validasi NSFP Tersedia: </span>
            <span className="font-mono text-slate-800 font-semibold">96 Nomor Seri</span>
          </div>
        </div>
      </div>

      {/* Multi-Branch Performance & Aging Summary Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Kontribusi Penjualan Antar Cabang */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">
                Performa Operasional Per Cabang
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Pengelolaan desentralisasi omset, stok, dan penanggung jawab
              </p>
            </div>
            <button
              onClick={() => onNavigateToTab('branches')}
              className="text-xs font-medium text-slate-700 hover:text-slate-950 transition-colors cursor-pointer"
            >
              Kelola Cabang →
            </button>
          </div>

          <div className="divide-y divide-slate-100">
            {branchMetrics.map((branch) => {
              const totalAllSales = branchMetrics.reduce((s, b) => s + b.sales, 0) || 1;
              const contributionPct = ((branch.sales / totalAllSales) * 100).toFixed(0);

              return (
                <div key={branch.id} className="py-3 flex items-center justify-between gap-4">
                  <div className="min-w-0">
                    <div className="flex items-center gap-2">
                      <span className="text-xs font-semibold text-slate-900 truncate">
                        {branch.name}
                      </span>
                      <span className="text-[11px] text-slate-400 font-mono">({branch.code})</span>
                    </div>
                    <p className="text-[11px] text-slate-500 mt-0.5 truncate">
                      PIC: {branch.managerName} · Total Stok: {branch.stockCount} unit
                    </p>
                  </div>

                  <div className="text-right shrink-0">
                    <div className="text-xs font-bold font-mono text-slate-900 tabular-nums">
                      {formatRupiah(branch.sales)}
                    </div>
                    <div className="text-[11px] text-slate-500">
                      Kontribusi: <span className="font-semibold text-slate-700">{contributionPct}%</span>
                    </div>
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Analisis Aging Piutang & Hutang Usaha */}
        <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <h2 className="text-sm font-semibold text-slate-900">
                Jadwal Jatuh Tempo (Aging Schedule)
              </h2>
              <p className="text-xs text-slate-500 mt-0.5">
                Mitigasi likuiditas piutang (AR) vs kewajiban hutang usaha (AP)
              </p>
            </div>
            <button
              onClick={() => onNavigateToTab('reports')}
              className="text-xs font-medium text-slate-700 hover:text-slate-950 transition-colors cursor-pointer"
            >
              Laporan Lengkap →
            </button>
          </div>

          <div className="space-y-3">
            {/* 0-30 Hari */}
            <div className="p-3 bg-slate-50 rounded-lg flex items-center justify-between text-xs">
              <div>
                <span className="font-semibold text-slate-900">Lancar (0 – 30 Hari)</span>
                <p className="text-slate-500 text-[11px]">Piutang berisiko rendah & tepat waktu</p>
              </div>
              <div className="text-right font-mono font-semibold text-slate-900 tabular-nums">
                {formatRupiah(summary.arBalance * 0.75)}
              </div>
            </div>

            {/* 31-60 Hari */}
            <div className="p-3 bg-slate-50 rounded-lg flex items-center justify-between text-xs">
              <div>
                <span className="font-semibold text-slate-900">Masa Tenggang (31 – 60 Hari)</span>
                <p className="text-slate-500 text-[11px]">Follow-up invoice penagihan berkala</p>
              </div>
              <div className="text-right font-mono font-semibold text-slate-900 tabular-nums">
                {formatRupiah(summary.arBalance * 0.20)}
              </div>
            </div>

            {/* >60 Hari */}
            <div className="p-3 bg-slate-50 rounded-lg flex items-center justify-between text-xs">
              <div>
                <span className="font-semibold text-amber-800">Perhatian Khusus (&gt; 60 Hari)</span>
                <p className="text-slate-500 text-[11px]">Penyisihan cadangan piutang tak tertagih</p>
              </div>
              <div className="text-right font-mono font-semibold text-amber-800 tabular-nums">
                {formatRupiah(summary.arBalance * 0.05)}
              </div>
            </div>

            {/* Total Hutang Usaha Supplier */}
            <div className="p-3 border border-slate-200 rounded-lg flex items-center justify-between text-xs">
              <div>
                <span className="font-semibold text-slate-900">Total Hutang Supplier (AP)</span>
                <p className="text-slate-500 text-[11px]">Kewajiban termin ke distributor IT</p>
              </div>
              <div className="text-right font-mono font-bold text-slate-900 tabular-nums">
                {formatRupiah(summary.apBalance || 198000000)}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
