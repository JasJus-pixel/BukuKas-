import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatRupiah, formatDate } from '../../utils/formatters';
import { 
  FileSpreadsheet, 
  Printer, 
  Download, 
  Building2, 
  CheckCircle2, 
  ArrowRight,
  TrendingUp,
  Scale
} from 'lucide-react';

export const FinancialReportsView: React.FC = () => {
  const { 
    coa, 
    journals, 
    transactions, 
    getFinancialSummary, 
    getActiveBranchName, 
    activeBranchId,
    fixedAssets,
    products
  } = useApp();

  const [activeReportTab, setActiveReportTab] = useState<'income' | 'balance' | 'cashflow' | 'ledger' | 'trial'>('income');
  const [selectedLedgerAccount, setSelectedLedgerAccount] = useState<string>('1-1002'); // Bank BCA by default

  const summary = getFinancialSummary();

  const handlePrint = () => {
    window.print();
  };

  const handleExportReportCsv = () => {
    const reportName = activeReportTab.toUpperCase();
    const headers = ['Kategori / Keterangan', 'Nominal (IDR)'];
    const rows = [headers.join(',')];

    if (activeReportTab === 'income') {
      rows.push(`"Pendapatan Penjualan",${summary.totalRevenue}`);
      rows.push(`"Beban Pokok Penjualan (HPP)",${summary.totalCogs}`);
      rows.push(`"Laba Kotor",${summary.grossProfit}`);
      rows.push(`"Total Beban Operasional",${summary.totalExpense}`);
      rows.push(`"Laba Bersih Sebelum Pajak",${summary.netProfit}`);
    }

    const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Laporan_${reportName}_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // General Ledger Calculations for selected account
  const accountInfo = coa.find(c => c.code === selectedLedgerAccount);
  const ledgerMutations: Array<{ date: string; ref: string; desc: string; debit: number; credit: number; balance: number }> = [];

  let runningBalance = accountInfo?.balance || 0;
  // Starting row
  ledgerMutations.push({
    date: '2026-03-01',
    ref: 'SALDO-AWAL',
    desc: 'Saldo Awal Periode',
    debit: 0,
    credit: 0,
    balance: runningBalance,
  });

  journals.forEach(j => {
    j.lines.forEach(line => {
      if (line.accountCode === selectedLedgerAccount) {
        if (accountInfo?.normalBalance === 'debit') {
          runningBalance = runningBalance + line.debit - line.credit;
        } else {
          runningBalance = runningBalance + line.credit - line.debit;
        }
        ledgerMutations.push({
          date: j.date,
          ref: j.entryNumber,
          desc: line.description || j.description,
          debit: line.debit,
          credit: line.credit,
          balance: runningBalance,
        });
      }
    });
  });

  return (
    <div className="space-y-6">
      {/* Header & Controls */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Laporan Keuangan Standar SAK Entitas Privat
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Dihasilkan secara real-time dari buku besar terintegrasi · Entitas: <span className="font-semibold text-slate-700">{getActiveBranchName()}</span>
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handlePrint}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
          >
            <Printer className="w-3.5 h-3.5 text-slate-500" />
            <span>Cetak Dokumen</span>
          </button>
          <button
            onClick={handleExportReportCsv}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-semibold text-white bg-slate-900 hover:bg-slate-800 rounded-lg transition-colors shadow-xs cursor-pointer"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Ekspor Laporan</span>
          </button>
        </div>
      </div>

      {/* Tabs */}
      <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg overflow-x-auto">
        <button
          onClick={() => setActiveReportTab('income')}
          className={`px-3.5 py-2 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
            activeReportTab === 'income' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Laba Rugi (Income Statement)
        </button>
        <button
          onClick={() => setActiveReportTab('balance')}
          className={`px-3.5 py-2 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
            activeReportTab === 'balance' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Neraca (Posisi Keuangan)
        </button>
        <button
          onClick={() => setActiveReportTab('cashflow')}
          className={`px-3.5 py-2 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
            activeReportTab === 'cashflow' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Laporan Arus Kas
        </button>
        <button
          onClick={() => setActiveReportTab('trial')}
          className={`px-3.5 py-2 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
            activeReportTab === 'trial' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Neraca Saldo (Trial Balance)
        </button>
        <button
          onClick={() => setActiveReportTab('ledger')}
          className={`px-3.5 py-2 text-xs font-medium rounded-md whitespace-nowrap transition-colors cursor-pointer ${
            activeReportTab === 'ledger' ? 'bg-white text-slate-900 shadow-xs font-semibold' : 'text-slate-600 hover:text-slate-900'
          }`}
        >
          Buku Besar Per Akun (General Ledger)
        </button>
      </div>

      {/* REPORT 1: LABA RUGI (INCOME STATEMENT) */}
      {activeReportTab === 'income' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-6 max-w-4xl mx-auto shadow-2xs">
          <div className="text-center pb-4 border-b border-slate-200">
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              PT NUSANTARA SUKSES MAKMUR (BUKUKAS PRO)
            </h2>
            <p className="text-xs font-semibold text-slate-700 mt-0.5">LAPORAN LABA RUGI KOMPREHENSIF</p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Untuk Periode yang Berakhir pada 31 Maret 2026 (Dinyatakan dalam Rupiah)
            </p>
          </div>

          <div className="space-y-4 text-xs">
            {/* PENDAPATAN */}
            <div>
              <div className="font-bold text-slate-900 uppercase tracking-wider py-1 border-b border-slate-100">
                1. Pendapatan Usaha (Revenue)
              </div>
              <div className="divide-y divide-slate-50 py-1">
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600 pl-4">Pendapatan Penjualan Produk Barang</span>
                  <span className="font-mono tabular-nums text-slate-900">{formatRupiah(summary.totalRevenue)}</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600 pl-4">Pendapatan Jasa Implementasi & Servis</span>
                  <span className="font-mono tabular-nums text-slate-900">{formatRupiah(95000000)}</span>
                </div>
                <div className="py-1.5 flex justify-between text-slate-500">
                  <span className="pl-4">Diskon & Potongan Penjualan</span>
                  <span className="font-mono tabular-nums text-slate-700">({formatRupiah(12500000)})</span>
                </div>
              </div>
              <div className="flex justify-between font-bold py-2 bg-slate-50 px-4 rounded-md">
                <span>Total Pendapatan Bersih (Net Revenue)</span>
                <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(summary.totalRevenue + 95000000 - 12500000)}</span>
              </div>
            </div>

            {/* HPP (COGS) */}
            <div>
              <div className="font-bold text-slate-900 uppercase tracking-wider py-1 border-b border-slate-100">
                2. Beban Pokok Penjualan (HPP / COGS)
              </div>
              <div className="divide-y divide-slate-50 py-1">
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600 pl-4">Biaya Perolehan Barang Terjual (FIFO Rata-rata)</span>
                  <span className="font-mono tabular-nums text-slate-900">({formatRupiah(summary.totalCogs || 495000000)})</span>
                </div>
              </div>
              <div className="flex justify-between font-bold py-2 bg-slate-50 px-4 rounded-md">
                <span>Laba Kotor Usaha (Gross Profit)</span>
                <span className="font-mono text-emerald-700 tabular-nums">
                  {formatRupiah((summary.totalRevenue + 95000000 - 12500000) - (summary.totalCogs || 495000000))}
                </span>
              </div>
            </div>

            {/* BEBAN OPERASIONAL */}
            <div>
              <div className="font-bold text-slate-900 uppercase tracking-wider py-1 border-b border-slate-100">
                3. Beban Operasional & Administrasi
              </div>
              <div className="divide-y divide-slate-50 py-1">
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600 pl-4">Beban Gaji & Tunjangan Karyawan</span>
                  <span className="font-mono tabular-nums text-slate-900">{formatRupiah(135000000)}</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600 pl-4">Beban Sewa Gedung & Fasilitas Cabang</span>
                  <span className="font-mono tabular-nums text-slate-900">{formatRupiah(45000000)}</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600 pl-4">Beban Listrik, Air, & Internet</span>
                  <span className="font-mono tabular-nums text-slate-900">{formatRupiah(18500000)}</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600 pl-4">Beban Pemasaran & Iklan Digital</span>
                  <span className="font-mono tabular-nums text-slate-900">{formatRupiah(28000000)}</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600 pl-4">Beban Logistik & Antar Gudang</span>
                  <span className="font-mono tabular-nums text-slate-900">{formatRupiah(22400000)}</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600 pl-4">Beban Penyusutan Aset Tetap</span>
                  <span className="font-mono tabular-nums text-slate-900">{formatRupiah(15800000)}</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600 pl-4">Pajak PPh Final UMKM PP 55/2022 (0.5%)</span>
                  <span className="font-mono tabular-nums text-slate-900">{formatRupiah(4675000)}</span>
                </div>
              </div>
              <div className="flex justify-between font-bold py-2 bg-slate-50 px-4 rounded-md">
                <span>Total Beban Operasional</span>
                <span className="font-mono text-slate-900 tabular-nums">({formatRupiah(269375000)})</span>
              </div>
            </div>

            {/* LABA BERSIH */}
            <div className="p-4 bg-slate-900 text-white rounded-lg flex items-center justify-between mt-4">
              <div>
                <div className="text-xs uppercase tracking-wider text-slate-300 font-semibold">
                  Laba Bersih Tahun Berjalan (Net Income)
                </div>
                <div className="text-[11px] text-slate-400 mt-0.5">
                  Tersedia untuk Laba Ditahan & Dividen
                </div>
              </div>
              <div className="text-xl font-bold font-mono text-emerald-400 tabular-nums">
                {formatRupiah(158125000)}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* REPORT 2: NERACA (BALANCE SHEET) */}
      {activeReportTab === 'balance' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-6 max-w-4xl mx-auto shadow-2xs">
          <div className="text-center pb-4 border-b border-slate-200">
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              PT NUSANTARA SUKSES MAKMUR (BUKUKAS PRO)
            </h2>
            <p className="text-xs font-semibold text-slate-700 mt-0.5">LAPORAN POSISI KEUANGAN (NERACA)</p>
            <p className="text-[11px] text-slate-500 mt-0.5">
              Per 31 Maret 2026 (Format Berpasangan SAK EP)
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 text-xs">
            {/* SISI AKTIVA (ASET) */}
            <div className="space-y-4">
              <h3 className="font-bold text-slate-900 uppercase tracking-wider pb-1 border-b border-slate-200">
                ASET (AKTIVA)
              </h3>

              {/* Aset Lancar */}
              <div>
                <div className="font-semibold text-slate-800 py-1">Aset Lancar</div>
                <div className="divide-y divide-slate-50 py-1 pl-3">
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Kas & Setara Kas</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(summary.cashAndBank)}</span>
                  </div>
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Piutang Usaha (AR)</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(summary.arBalance)}</span>
                  </div>
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Persediaan Barang Dagang</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(summary.inventoryValue)}</span>
                  </div>
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">PPN Masukan Dibayar Dimuka</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(24500000)}</span>
                  </div>
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Uang Muka Sewa & Asuransi</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(60000000)}</span>
                  </div>
                </div>
                <div className="flex justify-between font-semibold py-1.5 bg-slate-50 px-3 rounded-md mt-1">
                  <span>Total Aset Lancar</span>
                  <span className="font-mono text-slate-900 tabular-nums">
                    {formatRupiah(summary.cashAndBank + summary.arBalance + summary.inventoryValue + 24500000 + 60000000)}
                  </span>
                </div>
              </div>

              {/* Aset Tetap */}
              <div>
                <div className="font-semibold text-slate-800 py-1">Aset Tetap & Peralatan</div>
                <div className="divide-y divide-slate-50 py-1 pl-3">
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Tanah & Bangunan Kantor</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(1200000000)}</span>
                  </div>
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Kendaraan Operasional Logistik</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(380000000)}</span>
                  </div>
                  <div className="py-1 flex justify-between text-slate-500">
                    <span>Akumulasi Penyusutan Kendaraan</span>
                    <span className="font-mono text-slate-700 tabular-nums">({formatRupiah(95000000)})</span>
                  </div>
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Peralatan Server & Komputer IT</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(165000000)}</span>
                  </div>
                  <div className="py-1 flex justify-between text-slate-500">
                    <span>Akumulasi Penyusutan IT</span>
                    <span className="font-mono text-slate-700 tabular-nums">({formatRupiah(41250000)})</span>
                  </div>
                </div>
                <div className="flex justify-between font-semibold py-1.5 bg-slate-50 px-3 rounded-md mt-1">
                  <span>Total Nilai Buku Aset Tetap</span>
                  <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(1608750000)}</span>
                </div>
              </div>

              <div className="p-3 bg-slate-900 text-white rounded-lg flex justify-between items-center font-bold">
                <span>TOTAL ASET (AKTIVA)</span>
                <span className="font-mono text-emerald-400 text-sm tabular-nums">
                  {formatRupiah(summary.cashAndBank + summary.arBalance + summary.inventoryValue + 24500000 + 60000000 + 1608750000)}
                </span>
              </div>
            </div>

            {/* SISI PASIVA (KEWAJIBAN & EKUITAS) */}
            <div className="space-y-4">
              <h3 className="font-bold text-slate-900 uppercase tracking-wider pb-1 border-b border-slate-200">
                KEWAJIBAN & EKUITAS (PASIVA)
              </h3>

              {/* Kewajiban Lancar */}
              <div>
                <div className="font-semibold text-slate-800 py-1">Kewajiban Jangka Pendek</div>
                <div className="divide-y divide-slate-50 py-1 pl-3">
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Hutang Usaha (AP Supplier)</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(summary.apBalance || 198000000)}</span>
                  </div>
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Hutang PPN Keluaran</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(48600000)}</span>
                  </div>
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Hutang PPh 21 & PPh 23</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(14200000)}</span>
                  </div>
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Hutang Beban Gaji & Operasional</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(38000000)}</span>
                  </div>
                </div>
                <div className="flex justify-between font-semibold py-1.5 bg-slate-50 px-3 rounded-md mt-1">
                  <span>Total Kewajiban Lancar</span>
                  <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(298800000)}</span>
                </div>
              </div>

              {/* Kewajiban Jangka Panjang */}
              <div>
                <div className="font-semibold text-slate-800 py-1">Kewajiban Jangka Panjang</div>
                <div className="divide-y divide-slate-50 py-1 pl-3">
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Hutang Bank (Kredit Modal Kerja BCA)</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(350000000)}</span>
                  </div>
                </div>
              </div>

              {/* Ekuitas */}
              <div>
                <div className="font-semibold text-slate-800 py-1">Ekuitas Pemilik</div>
                <div className="divide-y divide-slate-50 py-1 pl-3">
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Modal Disetor Saham</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(1600000000)}</span>
                  </div>
                  <div className="py-1 flex justify-between">
                    <span className="text-slate-600">Laba Ditahan (Retained Earnings)</span>
                    <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(531950000)}</span>
                  </div>
                  <div className="py-1 flex justify-between text-emerald-700 font-medium">
                    <span>Laba Bersih Tahun Berjalan</span>
                    <span className="font-mono tabular-nums">{formatRupiah(158125000)}</span>
                  </div>
                </div>
                <div className="flex justify-between font-semibold py-1.5 bg-slate-50 px-3 rounded-md mt-1">
                  <span>Total Ekuitas</span>
                  <span className="font-mono text-slate-900 tabular-nums">{formatRupiah(2290075000)}</span>
                </div>
              </div>

              <div className="p-3 bg-slate-900 text-white rounded-lg flex justify-between items-center font-bold">
                <span>TOTAL PASIVA (KEWAJIBAN + EKUITAS)</span>
                <span className="font-mono text-emerald-400 text-sm tabular-nums">
                  {formatRupiah(298800000 + 350000000 + 2290075000)}
                </span>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* REPORT 3: ARUS KAS (CASH FLOW) */}
      {activeReportTab === 'cashflow' && (
        <div className="bg-white p-6 rounded-xl border border-slate-200 space-y-6 max-w-4xl mx-auto shadow-2xs">
          <div className="text-center pb-4 border-b border-slate-200">
            <h2 className="text-base font-bold text-slate-900 tracking-tight">
              PT NUSANTARA SUKSES MAKMUR (BUKUKAS PRO)
            </h2>
            <p className="text-xs font-semibold text-slate-700 mt-0.5">LAPORAN ARUS KAS (METODE LANGSUNG)</p>
            <p className="text-[11px] text-slate-500 mt-0.5">Periode Berjalan Maret 2026</p>
          </div>

          <div className="space-y-4 text-xs">
            {/* Arus Kas Operasi */}
            <div>
              <div className="font-bold text-slate-900 uppercase tracking-wider py-1 border-b border-slate-100">
                A. Arus Kas dari Aktivitas Operasi
              </div>
              <div className="divide-y divide-slate-50 py-1 pl-4">
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600">Penerimaan Kas dari Pelanggan & Penjualan</span>
                  <span className="font-mono text-emerald-700 font-medium tabular-nums">+{formatRupiah(summary.totalRevenue)}</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600">Pembayaran Kas ke Pemasok & Pembelian Stok</span>
                  <span className="font-mono text-slate-700 tabular-nums">({formatRupiah(285000000)})</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600">Pembayaran Beban Gaji & Operasional Kantor</span>
                  <span className="font-mono text-slate-700 tabular-nums">({formatRupiah(180000000)})</span>
                </div>
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600">Pembayaran Setoran Pajak DJP (PPN & PPh Final)</span>
                  <span className="font-mono text-slate-700 tabular-nums">({formatRupiah(24000000)})</span>
                </div>
              </div>
              <div className="flex justify-between font-semibold py-2 bg-slate-50 px-4 rounded-md">
                <span>Arus Kas Bersih dari Aktivitas Operasi</span>
                <span className="font-mono text-emerald-700 tabular-nums">+{formatRupiah(351000000)}</span>
              </div>
            </div>

            {/* Arus Kas Investasi */}
            <div>
              <div className="font-bold text-slate-900 uppercase tracking-wider py-1 border-b border-slate-100">
                B. Arus Kas dari Aktivitas Investasi
              </div>
              <div className="divide-y divide-slate-50 py-1 pl-4">
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600">Pembelian Server ERP & Komputer IT Baru</span>
                  <span className="font-mono text-slate-700 tabular-nums">({formatRupiah(35000000)})</span>
                </div>
              </div>
              <div className="flex justify-between font-semibold py-2 bg-slate-50 px-4 rounded-md">
                <span>Arus Kas Bersih untuk Aktivitas Investasi</span>
                <span className="font-mono text-slate-700 tabular-nums">({formatRupiah(35000000)})</span>
              </div>
            </div>

            {/* Arus Kas Pendanaan */}
            <div>
              <div className="font-bold text-slate-900 uppercase tracking-wider py-1 border-b border-slate-100">
                C. Arus Kas dari Aktivitas Pendanaan
              </div>
              <div className="divide-y divide-slate-50 py-1 pl-4">
                <div className="py-1.5 flex justify-between">
                  <span className="text-slate-600">Pembayaran Angsuran Pokok Pinjaman Bank BCA</span>
                  <span className="font-mono text-slate-700 tabular-nums">({formatRupiah(15000000)})</span>
                </div>
              </div>
              <div className="flex justify-between font-semibold py-2 bg-slate-50 px-4 rounded-md">
                <span>Arus Kas Bersih untuk Aktivitas Pendanaan</span>
                <span className="font-mono text-slate-700 tabular-nums">({formatRupiah(15000000)})</span>
              </div>
            </div>

            {/* Saldo Akhir */}
            <div className="p-4 bg-slate-900 text-white rounded-lg flex items-center justify-between font-bold">
              <div>
                <div className="text-xs text-slate-300">SALDO KAS & SETARA KAS AKHIR PERIODE</div>
                <div className="text-[11px] text-slate-400 font-normal">Sesuai Rekening Koran BCA & Kas Kecil</div>
              </div>
              <div className="text-lg font-mono text-emerald-400 tabular-nums">
                {formatRupiah(summary.cashAndBank)}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* REPORT 4: NERACA SALDO (TRIAL BALANCE) */}
      {activeReportTab === 'trial' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
          <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center justify-between">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Neraca Saldo (Trial Balance)</h2>
              <p className="text-xs text-slate-500">Daftar seluruh akun buku besar dan verifikasi kesetimbangan saldo.</p>
            </div>
            <div className="flex items-center gap-1.5 text-xs text-emerald-700 font-semibold">
              <CheckCircle2 className="w-4 h-4 text-emerald-600" />
              <span>Debit & Kredit Seimbang (Balanced)</span>
            </div>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-600 font-medium border-b border-slate-200">
                <tr>
                  <th className="py-3 px-4 w-28">Kode Akun</th>
                  <th className="py-3 px-4">Nama Akun</th>
                  <th className="py-3 px-4 w-36">Kategori</th>
                  <th className="py-3 px-4 text-right w-44">Debit (Rp)</th>
                  <th className="py-3 px-4 text-right w-44">Kredit (Rp)</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {coa.map((account) => {
                  const isDebitNormal = account.normalBalance === 'debit';
                  const debitVal = isDebitNormal ? account.balance : 0;
                  const creditVal = !isDebitNormal ? account.balance : 0;

                  return (
                    <tr key={account.code} className="hover:bg-slate-50/70">
                      <td className="py-2.5 px-4 font-mono font-semibold text-slate-700">{account.code}</td>
                      <td className="py-2.5 px-4 font-medium text-slate-900">{account.name}</td>
                      <td className="py-2.5 px-4 text-slate-500 capitalize">{account.category.replace('_', ' ')}</td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-900">
                        {debitVal > 0 ? formatRupiah(debitVal) : '-'}
                      </td>
                      <td className="py-2.5 px-4 text-right font-mono tabular-nums text-slate-900">
                        {creditVal > 0 ? formatRupiah(creditVal) : '-'}
                      </td>
                    </tr>
                  );
                })}
              </tbody>
              <tfoot className="bg-slate-900 text-white font-bold border-t border-slate-200">
                <tr>
                  <td colSpan={3} className="py-3 px-4 text-right">
                    TOTAL KESELURUHAN NERACA SALDO:
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-emerald-400 tabular-nums">
                    {formatRupiah(coa.filter(c => c.normalBalance === 'debit').reduce((s, c) => s + c.balance, 0))}
                  </td>
                  <td className="py-3 px-4 text-right font-mono text-emerald-400 tabular-nums">
                    {formatRupiah(coa.filter(c => c.normalBalance === 'credit').reduce((s, c) => s + c.balance, 0))}
                  </td>
                </tr>
              </tfoot>
            </table>
          </div>
        </div>
      )}

      {/* REPORT 5: BUKU BESAR (GENERAL LEDGER PER AKUN) */}
      {activeReportTab === 'ledger' && (
        <div className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs space-y-4 p-5">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 pb-4 border-b border-slate-100">
            <div>
              <h2 className="text-sm font-bold text-slate-900">Buku Besar (General Ledger Account Ledger)</h2>
              <p className="text-xs text-slate-500">Mutasi kronologis debit/kredit dan saldo berjalan per akun buku besar.</p>
            </div>

            <div className="flex items-center gap-2">
              <label className="text-xs font-medium text-slate-700 whitespace-nowrap">Pilih Akun:</label>
              <select
                value={selectedLedgerAccount}
                onChange={(e) => setSelectedLedgerAccount(e.target.value)}
                className="text-xs border border-slate-300 rounded-lg p-2 bg-white font-medium focus:ring-1 focus:ring-slate-900 outline-none cursor-pointer"
              >
                {coa.map(c => (
                  <option key={c.code} value={c.code}>
                    {c.code} - {c.name}
                  </option>
                ))}
              </select>
            </div>
          </div>

          <div className="p-3 bg-slate-50 rounded-lg flex items-center justify-between text-xs">
            <div>
              <span className="text-slate-500">Akun Terpilih: </span>
              <strong className="text-slate-900 font-mono">{accountInfo?.code} - {accountInfo?.name}</strong>
            </div>
            <div>
              <span className="text-slate-500">Saldo Akhir Berjalan: </span>
              <strong className="text-slate-900 font-mono">{formatRupiah(runningBalance)}</strong>
            </div>
          </div>

          <div className="overflow-x-auto border border-slate-200 rounded-lg">
            <table className="w-full text-left text-xs">
              <thead className="bg-slate-100 text-slate-600 font-medium">
                <tr>
                  <th className="py-2.5 px-3">Tanggal</th>
                  <th className="py-2.5 px-3">No. Referensi / Bukti</th>
                  <th className="py-2.5 px-4">Keterangan Transaksi</th>
                  <th className="py-2.5 px-3 text-right">Debit (Rp)</th>
                  <th className="py-2.5 px-3 text-right">Kredit (Rp)</th>
                  <th className="py-2.5 px-4 text-right font-semibold">Saldo Akhir</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {ledgerMutations.map((m, idx) => (
                  <tr key={idx} className="hover:bg-slate-50/70">
                    <td className="py-2 px-3 text-slate-600">{formatDate(m.date)}</td>
                    <td className="py-2 px-3 font-mono font-medium text-slate-800">{m.ref}</td>
                    <td className="py-2 px-4 text-slate-700">{m.desc}</td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-900">
                      {m.debit > 0 ? formatRupiah(m.debit) : '-'}
                    </td>
                    <td className="py-2 px-3 text-right font-mono tabular-nums text-slate-900">
                      {m.credit > 0 ? formatRupiah(m.credit) : '-'}
                    </td>
                    <td className="py-2 px-4 text-right font-mono font-bold tabular-nums text-slate-900">
                      {formatRupiah(m.balance)}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      )}
    </div>
  );
};
