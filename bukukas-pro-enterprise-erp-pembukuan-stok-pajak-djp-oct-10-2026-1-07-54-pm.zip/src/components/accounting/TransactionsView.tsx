import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatRupiah, formatDate, validateNpwp } from '../../utils/formatters';
import { TransactionType, PaymentMethod } from '../../types/accounting';
import { Modal } from '../common/Modal';
import { 
  Plus, 
  Search, 
  Filter, 
  Receipt, 
  ArrowDownLeft, 
  ArrowUpRight, 
  CreditCard, 
  CheckCircle, 
  AlertCircle,
  FileText
} from 'lucide-react';

interface TransactionsViewProps {
  onOpenJournalDetail?: (referenceId: string) => void;
}

export const TransactionsView: React.FC<TransactionsViewProps> = ({ onOpenJournalDetail }) => {
  const { 
    transactions, 
    branches, 
    activeBranchId, 
    products, 
    coa, 
    addTransaction, 
    currentUser 
  } = useApp();

  const [activeTab, setActiveTab] = useState<'all' | 'sale' | 'purchase' | 'expense'>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [selectedTxDetail, setSelectedTxDetail] = useState<any | null>(null);

  // Form State
  const [formType, setFormType] = useState<TransactionType>('sale');
  const [formBranchId, setFormBranchId] = useState<string>(activeBranchId === 'all' ? 'br-jkt' : activeBranchId);
  const [formDate, setFormDate] = useState<string>(new Date().toISOString().split('T')[0]);
  const [formCounterparty, setFormCounterparty] = useState<string>('');
  const [formNpwp, setFormNpwp] = useState<string>('');
  const [formPaymentMethod, setFormPaymentMethod] = useState<PaymentMethod>('bank_transfer');
  const [formPaymentStatus, setFormPaymentStatus] = useState<'paid' | 'unpaid'>('paid');
  const [formCategoryAccount, setFormCategoryAccount] = useState<string>('4-1001');
  const [formPaymentAccount, setFormPaymentAccount] = useState<string>('1-1002'); // Bank BCA
  const [formTaxType, setFormTaxType] = useState<'ppn_11' | 'ppn_12' | 'pph_23' | 'none'>('ppn_11');
  const [formNotes, setFormNotes] = useState<string>('');

  // Items for sale/purchase
  const [formItems, setFormItems] = useState<{ productId: string; qty: number; unitPrice: number }[]>([
    { productId: products[0]?.id || '', qty: 1, unitPrice: products[0]?.sellingPrice || 1000000 }
  ]);
  const [expenseAmount, setExpenseAmount] = useState<number>(5000000);

  // Filter transactions
  const filtered = transactions.filter(t => {
    const matchesBranch = activeBranchId === 'all' || t.branchId === activeBranchId;
    const matchesType = activeTab === 'all' || t.type === activeTab;
    const matchesSearch = 
      t.refNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      t.counterpartyName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (t.notes || '').toLowerCase().includes(searchTerm.toLowerCase());
    return matchesBranch && matchesType && matchesSearch;
  });

  // Calculate totals for the new transaction
  const calculateFormTotals = () => {
    let subtotal = 0;
    if (formType === 'expense') {
      subtotal = Number(expenseAmount) || 0;
    } else {
      subtotal = formItems.reduce((sum, item) => sum + (Number(item.qty) || 0) * (Number(item.unitPrice) || 0), 0);
    }

    let taxAmount = 0;
    let total = subtotal;

    if (formTaxType === 'ppn_11') {
      taxAmount = Math.round(subtotal * 0.11);
      total = subtotal + taxAmount;
    } else if (formTaxType === 'ppn_12') {
      taxAmount = Math.round(subtotal * 0.12);
      total = subtotal + taxAmount;
    } else if (formTaxType === 'pph_23') {
      taxAmount = Math.round(subtotal * 0.02);
      total = subtotal - taxAmount; // Dipotong PPh 23
    }

    return { subtotal, taxAmount, total };
  };

  const totals = calculateFormTotals();

  const handleAddItem = () => {
    const prd = products[0];
    setFormItems(prev => [
      ...prev,
      { productId: prd ? prd.id : '', qty: 1, unitPrice: prd ? (formType === 'sale' ? prd.sellingPrice : prd.costPrice) : 0 }
    ]);
  };

  const handleRemoveItem = (index: number) => {
    setFormItems(prev => prev.filter((_, i) => i !== index));
  };

  const handleProductChange = (index: number, productId: string) => {
    const prd = products.find(p => p.id === productId);
    if (!prd) return;
    const newItems = [...formItems];
    newItems[index].productId = productId;
    newItems[index].unitPrice = formType === 'sale' ? prd.sellingPrice : prd.costPrice;
    setFormItems(newItems);
  };

  const handleSaveTransaction = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formCounterparty.trim()) {
      alert('Mohon isi nama pihak lawan transaksi (pelanggan / supplier / penerima).');
      return;
    }

    // Build items
    const itemsPayload = formType === 'expense' ? [] : formItems.map(item => {
      const prd = products.find(p => p.id === item.productId);
      const sub = item.qty * item.unitPrice;
      const taxPart = formTaxType === 'ppn_11' ? Math.round(sub * 0.11) : formTaxType === 'ppn_12' ? Math.round(sub * 0.12) : 0;
      return {
        productId: item.productId,
        productName: prd ? prd.name : 'Item Transaksi',
        sku: prd ? prd.sku : 'SKU-001',
        qty: item.qty,
        unitPrice: item.unitPrice,
        subtotal: sub,
        taxPercent: formTaxType === 'ppn_11' ? 11 : formTaxType === 'ppn_12' ? 12 : 0,
        taxAmount: taxPart,
      };
    });

    addTransaction({
      date: formDate,
      type: formType,
      branchId: formBranchId,
      counterpartyName: formCounterparty,
      counterpartyNpwp: formNpwp || undefined,
      categoryAccountCode: formCategoryAccount,
      paymentAccountCode: formPaymentAccount,
      paymentMethod: formPaymentMethod,
      paymentStatus: formPaymentStatus,
      subtotal: totals.subtotal,
      taxAmount: totals.taxAmount,
      taxType: formTaxType,
      totalAmount: totals.total,
      notes: formNotes,
      items: itemsPayload,
      createdBy: currentUser.name,
    });

    setIsModalOpen(false);
    // Reset Form
    setFormCounterparty('');
    setFormNpwp('');
    setFormNotes('');
  };

  return (
    <div className="space-y-6">
      {/* Header & Action Button */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Transaksi Harian & Pembukuan Otomatis
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Setiap pencatatan langsung menghasilkan ayat Jurnal Umum (Double-Entry) dan mutasi stok secara otomatis.
          </p>
        </div>

        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors shadow-xs cursor-pointer self-start sm:self-auto"
        >
          <Plus className="w-3.5 h-3.5" />
          <span>Catat Transaksi Baru</span>
        </button>
      </div>

      {/* Filter and Search Bar */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
          <button
            onClick={() => setActiveTab('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Semua ({transactions.length})
          </button>
          <button
            onClick={() => setActiveTab('sale')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'sale' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Penjualan
          </button>
          <button
            onClick={() => setActiveTab('purchase')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'purchase' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pembelian
          </button>
          <button
            onClick={() => setActiveTab('expense')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              activeTab === 'expense' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pengeluaran
          </button>
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari no. faktur, lawan transaksi..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg w-full sm:w-64 focus:ring-1 focus:ring-slate-900 focus:border-slate-900 outline-none"
          />
        </div>
      </div>

      {/* Transactions Data Table */}
      <div className="bg-white rounded-xl border border-slate-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-50 border-b border-slate-200 text-slate-500 font-medium">
              <tr>
                <th className="py-3 px-4">No. Bukti / Tanggal</th>
                <th className="py-3 px-4">Tipe & Cabang</th>
                <th className="py-3 px-4">Lawan Transaksi</th>
                <th className="py-3 px-4">Metode Bayar</th>
                <th className="py-3 px-4 text-right">Subtotal</th>
                <th className="py-3 px-4 text-right">Pajak (PPN/PPh)</th>
                <th className="py-3 px-4 text-right">Total Transaksi</th>
                <th className="py-3 px-4 text-center">Status</th>
                <th className="py-3 px-4 text-center">Aksi</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.length === 0 ? (
                <tr>
                  <td colSpan={9} className="py-12 text-center text-slate-500">
                    Tidak ada transaksi ditemukan untuk kriteria ini.
                  </td>
                </tr>
              ) : (
                filtered.map((t) => {
                  const branch = branches.find(b => b.id === t.branchId);

                  return (
                    <tr key={t.id} className="hover:bg-slate-50/70 transition-colors">
                      <td className="py-3 px-4">
                        <div className="font-semibold text-slate-900 font-mono">{t.refNumber}</div>
                        <div className="text-[11px] text-slate-500 mt-0.5">{formatDate(t.date)}</div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-800">
                          {t.type === 'sale' ? 'Penjualan' : t.type === 'purchase' ? 'Pembelian' : 'Pengeluaran'}
                        </div>
                        <div className="text-[11px] text-slate-500 mt-0.5">
                          {branch ? branch.code : 'Pusat'}
                        </div>
                      </td>
                      <td className="py-3 px-4">
                        <div className="font-medium text-slate-900">{t.counterpartyName}</div>
                        {t.counterpartyNpwp && (
                          <div className="text-[11px] text-slate-500 font-mono">
                            NPWP: {t.counterpartyNpwp}
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span className="text-slate-700 capitalize">
                          {t.paymentMethod === 'bank_transfer' ? 'Transfer Bank' : t.paymentMethod === 'cash' ? 'Tunai Kasir' : 'Kredit 30 Hari'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                        {formatRupiah(t.subtotal)}
                      </td>
                      <td className="py-3 px-4 text-right font-mono tabular-nums text-slate-700">
                        {t.taxAmount > 0 ? (
                          <span>{formatRupiah(t.taxAmount)} ({t.taxType === 'ppn_11' ? 'PPN 11%' : t.taxType === 'pph_23' ? 'PPh 23' : 'Pajak'})</span>
                        ) : (
                          <span className="text-slate-400">Rp 0</span>
                        )}
                      </td>
                      <td className="py-3 px-4 text-right font-mono font-bold tabular-nums text-slate-900">
                        {formatRupiah(t.totalAmount)}
                      </td>
                      <td className="py-3 px-4 text-center">
                        <span className={`inline-block text-[11px] font-medium ${
                          t.paymentStatus === 'paid' ? 'text-emerald-700' : 'text-amber-700'
                        }`}>
                          {t.paymentStatus === 'paid' ? 'Lunas' : 'Belum Lunas'}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-center">
                        <button
                          onClick={() => setSelectedTxDetail(t)}
                          className="px-2.5 py-1 text-[11px] text-slate-700 hover:text-slate-900 hover:bg-slate-100 rounded-md transition-colors cursor-pointer"
                        >
                          Rincian
                        </button>
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Detail Modal */}
      {selectedTxDetail && (
        <Modal
          isOpen={!!selectedTxDetail}
          onClose={() => setSelectedTxDetail(null)}
          title={`Detail Transaksi ${selectedTxDetail.refNumber}`}
          subtitle={`Dicatat pada ${selectedTxDetail.createdAt} oleh ${selectedTxDetail.createdBy}`}
        >
          <div className="space-y-4 text-xs">
            <div className="grid grid-cols-2 gap-4 p-4 bg-slate-50 rounded-lg">
              <div>
                <span className="text-slate-500">Pihak Terkait:</span>
                <p className="font-semibold text-slate-900 mt-0.5">{selectedTxDetail.counterpartyName}</p>
                {selectedTxDetail.counterpartyNpwp && (
                  <p className="font-mono text-slate-500 mt-0.5">NPWP: {selectedTxDetail.counterpartyNpwp}</p>
                )}
              </div>
              <div>
                <span className="text-slate-500">Metode & Status:</span>
                <p className="font-semibold text-slate-900 mt-0.5 capitalize">
                  {selectedTxDetail.paymentMethod} · {selectedTxDetail.paymentStatus === 'paid' ? 'Lunas' : 'Belum Lunas'}
                </p>
                <p className="text-slate-500 mt-0.5">Tanggal: {formatDate(selectedTxDetail.date)}</p>
              </div>
            </div>

            {selectedTxDetail.items && selectedTxDetail.items.length > 0 && (
              <div>
                <h4 className="font-semibold text-slate-900 mb-2">Rincian Barang / Jasa:</h4>
                <div className="border border-slate-200 rounded-lg overflow-hidden">
                  <table className="w-full text-left">
                    <thead className="bg-slate-50 text-slate-500">
                      <tr>
                        <th className="p-2.5">Nama Item</th>
                        <th className="p-2.5 text-center">Qty</th>
                        <th className="p-2.5 text-right">Harga Satuan</th>
                        <th className="p-2.5 text-right">Total</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {selectedTxDetail.items.map((item: any, idx: number) => (
                        <tr key={idx}>
                          <td className="p-2.5 font-medium text-slate-900">{item.productName}</td>
                          <td className="p-2.5 text-center font-mono">{item.qty}</td>
                          <td className="p-2.5 text-right font-mono">{formatRupiah(item.unitPrice)}</td>
                          <td className="p-2.5 text-right font-mono font-semibold">{formatRupiah(item.subtotal)}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            )}

            <div className="space-y-1.5 p-4 border border-slate-200 rounded-lg text-right">
              <div className="flex justify-between">
                <span className="text-slate-500">Subtotal:</span>
                <span className="font-mono font-medium">{formatRupiah(selectedTxDetail.subtotal)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-slate-500">Pajak ({selectedTxDetail.taxType}):</span>
                <span className="font-mono font-medium">{formatRupiah(selectedTxDetail.taxAmount)}</span>
              </div>
              <div className="flex justify-between text-sm font-bold border-t border-slate-200 pt-1.5">
                <span>Total Bersih:</span>
                <span className="font-mono text-slate-900">{formatRupiah(selectedTxDetail.totalAmount)}</span>
              </div>
            </div>

            {selectedTxDetail.notes && (
              <div className="text-slate-600 bg-slate-50 p-3 rounded-lg">
                <span className="font-semibold text-slate-800">Catatan: </span>
                {selectedTxDetail.notes}
              </div>
            )}
          </div>
        </Modal>
      )}

      {/* Modal Catat Transaksi Baru */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Catat Transaksi Harian Baru"
        subtitle="Sistem secara otomatis akan menjurnal transaksi ke buku besar dan memperbarui stok barang."
        maxWidth="3xl"
      >
        <form onSubmit={handleSaveTransaction} className="space-y-5 text-xs">
          {/* Tipe Transaksi Tabs */}
          <div>
            <label className="block font-medium text-slate-700 mb-1.5">Jenis Transaksi</label>
            <div className="grid grid-cols-3 gap-2">
              <button
                type="button"
                onClick={() => {
                  setFormType('sale');
                  setFormCategoryAccount('4-1001');
                }}
                className={`py-2 px-3 rounded-lg border text-center font-semibold transition-colors cursor-pointer ${
                  formType === 'sale'
                    ? 'border-slate-900 bg-slate-900 text-white'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                Penjualan (Sales)
              </button>
              <button
                type="button"
                onClick={() => {
                  setFormType('purchase');
                  setFormCategoryAccount('1-1005');
                }}
                className={`py-2 px-3 rounded-lg border text-center font-semibold transition-colors cursor-pointer ${
                  formType === 'purchase'
                    ? 'border-slate-900 bg-slate-900 text-white'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                Pembelian (Purchase)
              </button>
              <button
                type="button"
                onClick={() => {
                  setFormType('expense');
                  setFormCategoryAccount('6-1003');
                }}
                className={`py-2 px-3 rounded-lg border text-center font-semibold transition-colors cursor-pointer ${
                  formType === 'expense'
                    ? 'border-slate-900 bg-slate-900 text-white'
                    : 'border-slate-200 bg-white text-slate-700 hover:bg-slate-50'
                }`}
              >
                Beban / Pengeluaran (Expense)
              </button>
            </div>
          </div>

          {/* Basic Fields */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Tanggal Transaksi</label>
              <input
                type="date"
                value={formDate}
                onChange={(e) => setFormDate(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Cabang Usaha</label>
              <select
                value={formBranchId}
                onChange={(e) => setFormBranchId(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none"
              >
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name} ({b.city})</option>
                ))}
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Status Pembayaran</label>
              <select
                value={formPaymentStatus}
                onChange={(e) => setFormPaymentStatus(e.target.value as any)}
                className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none"
              >
                <option value="paid">Lunas Seketika</option>
                <option value="unpaid">Belum Lunas (Kredit / Piutang)</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">
                {formType === 'sale' ? 'Nama Pelanggan (Customer)' : formType === 'purchase' ? 'Nama Pemasok (Vendor)' : 'Nama Penerima Pembayaran'}
              </label>
              <input
                type="text"
                placeholder={formType === 'sale' ? 'contoh: PT Solusi Mega Persada' : 'contoh: PT Synnex Distribusi'}
                value={formCounterparty}
                onChange={(e) => setFormCounterparty(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">NPWP / NIK Lawan Transaksi (16 Digit)</label>
              <input
                type="text"
                placeholder="0123456789010000"
                value={formNpwp}
                onChange={(e) => setFormNpwp(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none font-mono"
              />
            </div>
          </div>

          {/* Items or Expense Amount */}
          {formType === 'expense' ? (
            <div className="p-4 bg-slate-50 rounded-lg space-y-3">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Kategori Akun Beban</label>
                  <select
                    value={formCategoryAccount}
                    onChange={(e) => setFormCategoryAccount(e.target.value)}
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none"
                  >
                    {coa.filter(c => c.category === 'expense_operational').map(c => (
                      <option key={c.code} value={c.code}>{c.code} - {c.name}</option>
                    ))}
                  </select>
                </div>
                <div>
                  <label className="block font-medium text-slate-700 mb-1">Nominal Beban (Rp)</label>
                  <input
                    type="number"
                    value={expenseAmount}
                    onChange={(e) => setExpenseAmount(Number(e.target.value))}
                    min={0}
                    step={10000}
                    required
                    className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none font-mono font-semibold"
                  />
                </div>
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center justify-between">
                <label className="font-semibold text-slate-800">Daftar Barang & Kuantitas</label>
                <button
                  type="button"
                  onClick={handleAddItem}
                  className="text-xs text-slate-900 font-semibold hover:underline cursor-pointer"
                >
                  + Tambah Baris Produk
                </button>
              </div>

              <div className="space-y-2">
                {formItems.map((item, idx) => (
                  <div key={idx} className="flex items-center gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                    <div className="flex-1">
                      <select
                        value={item.productId}
                        onChange={(e) => handleProductChange(idx, e.target.value)}
                        className="w-full border border-slate-300 rounded-md p-1.5 bg-white outline-none"
                      >
                        {products.map(p => (
                          <option key={p.id} value={p.id}>
                            {p.sku} - {p.name} (Stok: {p.stocksByBranch[formBranchId] || 0})
                          </option>
                        ))}
                      </select>
                    </div>
                    <div className="w-20">
                      <input
                        type="number"
                        min={1}
                        value={item.qty}
                        onChange={(e) => {
                          const newItems = [...formItems];
                          newItems[idx].qty = Number(e.target.value);
                          setFormItems(newItems);
                        }}
                        placeholder="Qty"
                        className="w-full border border-slate-300 rounded-md p-1.5 bg-white text-center font-mono outline-none"
                      />
                    </div>
                    <div className="w-32">
                      <input
                        type="number"
                        value={item.unitPrice}
                        onChange={(e) => {
                          const newItems = [...formItems];
                          newItems[idx].unitPrice = Number(e.target.value);
                          setFormItems(newItems);
                        }}
                        placeholder="Harga"
                        className="w-full border border-slate-300 rounded-md p-1.5 bg-white text-right font-mono outline-none"
                      />
                    </div>
                    <div className="w-28 text-right font-mono font-semibold text-slate-900 tabular-nums">
                      {formatRupiah(item.qty * item.unitPrice)}
                    </div>
                    {formItems.length > 1 && (
                      <button
                        type="button"
                        onClick={() => handleRemoveItem(idx)}
                        className="p-1 text-slate-400 hover:text-red-600 transition-colors cursor-pointer"
                      >
                        ×
                      </button>
                    )}
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* Payment & Tax Options */}
          <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 p-4 bg-slate-50 rounded-lg">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Rekening Pembayaran</label>
              <select
                value={formPaymentAccount}
                onChange={(e) => setFormPaymentAccount(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 bg-white focus:ring-1 focus:ring-slate-900 outline-none"
              >
                <option value="1-1002">1-1002 - Bank BCA Operasional</option>
                <option value="1-1001">1-1001 - Kas Kecil (Petty Cash)</option>
                <option value="1-1003">1-1003 - Bank Mandiri Payroll</option>
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Metode Transfer</label>
              <select
                value={formPaymentMethod}
                onChange={(e) => setFormPaymentMethod(e.target.value as any)}
                className="w-full border border-slate-300 rounded-lg p-2 bg-white focus:ring-1 focus:ring-slate-900 outline-none"
              >
                <option value="bank_transfer">Transfer Bank (Giro/BCA)</option>
                <option value="cash">Tunai / Petty Cash</option>
                <option value="qris">QRIS Statis/Dinamis</option>
                <option value="credit">Termin Invoice (Kredit)</option>
              </select>
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Perhitungan Pajak DJP</label>
              <select
                value={formTaxType}
                onChange={(e) => setFormTaxType(e.target.value as any)}
                className="w-full border border-slate-300 rounded-lg p-2 bg-white focus:ring-1 focus:ring-slate-900 outline-none"
              >
                <option value="ppn_11">PPN 11% (UU HPP Standard)</option>
                <option value="ppn_12">PPN 12% (Simulasi Regulasi Baru)</option>
                <option value="pph_23">PPh 23 (2% Pemotongan Jasa)</option>
                <option value="none">Bebas Pajak / Non-PKP</option>
              </select>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block font-medium text-slate-700 mb-1">Catatan / Keterangan Transaksi</label>
            <textarea
              rows={2}
              value={formNotes}
              onChange={(e) => setFormNotes(e.target.value)}
              placeholder="Keterangan pengiriman, PO number, atau detail transaksi..."
              className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none"
            />
          </div>

          {/* Summary Box */}
          <div className="p-4 bg-slate-900 text-white rounded-lg flex items-center justify-between">
            <div>
              <div className="text-slate-400 text-[11px]">Ringkasan Nilai Transaksi:</div>
              <div className="text-xs text-slate-300 mt-0.5">
                DPP: <span className="font-mono">{formatRupiah(totals.subtotal)}</span> · Pajak: <span className="font-mono">{formatRupiah(totals.taxAmount)}</span>
              </div>
            </div>
            <div className="text-right">
              <div className="text-[10px] uppercase tracking-wider text-slate-400">Total Akhir</div>
              <div className="text-xl font-bold font-mono tabular-nums text-white">
                {formatRupiah(totals.total)}
              </div>
            </div>
          </div>

          {/* Actions */}
          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              className="px-5 py-2 bg-slate-900 hover:bg-slate-800 text-white font-semibold rounded-lg transition-colors cursor-pointer"
            >
              Simpan & Jurnal Otomatis
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
