import React, { useState } from 'react';
import { useApp } from '../../context/AppContext';
import { formatRupiah, formatDate } from '../../utils/formatters';
import { Modal } from '../common/Modal';
import { 
  Plus, 
  Search, 
  Download, 
  CheckCircle2, 
  AlertCircle, 
  BookOpen, 
  FileSpreadsheet 
} from 'lucide-react';

export const JournalView: React.FC = () => {
  const { 
    journals, 
    activeBranchId, 
    branches, 
    coa, 
    addManualJournal, 
    currentUser 
  } = useApp();

  const [searchTerm, setSearchTerm] = useState('');
  const [filterType, setFilterType] = useState<string>('all');
  const [isModalOpen, setIsModalOpen] = useState(false);

  // Manual Journal Form State
  const [formDate, setFormDate] = useState(new Date().toISOString().split('T')[0]);
  const [formBranchId, setFormBranchId] = useState(activeBranchId === 'all' ? 'br-jkt' : activeBranchId);
  const [formDescription, setFormDescription] = useState('');
  const [journalLines, setJournalLines] = useState<Array<{ accountCode: string; debit: number; credit: number; description: string }>>([
    { accountCode: '6-1002', debit: 5000000, credit: 0, description: 'Beban sewa dibayar di muka' },
    { accountCode: '1-1007', debit: 0, credit: 5000000, description: 'Amortisasi uang muka sewa' },
  ]);

  const filtered = journals.filter(j => {
    const matchesBranch = activeBranchId === 'all' || j.branchId === activeBranchId;
    const matchesType = filterType === 'all' || j.referenceType === filterType;
    const matchesSearch = 
      j.entryNumber.toLowerCase().includes(searchTerm.toLowerCase()) ||
      j.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
      j.lines.some(l => l.accountName.toLowerCase().includes(searchTerm.toLowerCase()));
    return matchesBranch && matchesType && matchesSearch;
  });

  const grandTotalDebit = filtered.reduce((sum, j) => sum + j.totalDebit, 0);
  const grandTotalCredit = filtered.reduce((sum, j) => sum + j.totalCredit, 0);

  // Manual entry calculations
  const totalDebitManual = journalLines.reduce((sum, l) => sum + (Number(l.debit) || 0), 0);
  const totalCreditManual = journalLines.reduce((sum, l) => sum + (Number(l.credit) || 0), 0);
  const isFormBalanced = totalDebitManual === totalCreditManual && totalDebitManual > 0;

  const handleAddLine = () => {
    setJournalLines(prev => [
      ...prev,
      { accountCode: coa[0]?.code || '1-1001', debit: 0, credit: 0, description: '' }
    ]);
  };

  const handleRemoveLine = (idx: number) => {
    setJournalLines(prev => prev.filter((_, i) => i !== idx));
  };

  const handleLineChange = (index: number, field: string, value: any) => {
    const updated = [...journalLines];
    updated[index] = { ...updated[index], [field]: value };
    setJournalLines(updated);
  };

  const handleSaveManualJournal = (e: React.FormEvent) => {
    e.preventDefault();
    if (!isFormBalanced) {
      alert('Debit dan Kredit harus seimbang dan lebih dari 0.');
      return;
    }

    const linesPayload = journalLines.map(l => {
      const account = coa.find(c => c.code === l.accountCode);
      return {
        accountCode: l.accountCode,
        accountName: account ? account.name : l.accountCode,
        debit: Number(l.debit) || 0,
        credit: Number(l.credit) || 0,
        description: l.description,
      };
    });

    const success = addManualJournal({
      date: formDate,
      referenceType: 'manual',
      branchId: formBranchId,
      description: formDescription || 'Jurnal Penyesuaian Manual',
      lines: linesPayload,
      totalDebit: totalDebitManual,
      totalCredit: totalCreditManual,
      createdBy: currentUser.name,
    });

    if (success) {
      setIsModalOpen(false);
      setFormDescription('');
    }
  };

  const exportJournalCsv = () => {
    const headers = ['No. Jurnal', 'Tanggal', 'Cabang', 'Keterangan', 'Kode Akun', 'Nama Akun', 'Debit', 'Kredit'];
    const rows: string[] = [headers.join(',')];

    filtered.forEach(j => {
      j.lines.forEach(l => {
        rows.push([
          `"${j.entryNumber}"`,
          `"${j.date}"`,
          `"${j.branchId}"`,
          `"${j.description.replace(/"/g, '""')}"`,
          `"${l.accountCode}"`,
          `"${l.accountName.replace(/"/g, '""')}"`,
          l.debit,
          l.credit,
        ].join(','));
      });
    });

    const blob = new Blob([rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `Jurnal_Umum_${new Date().toISOString().split('T')[0]}.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-xl font-bold tracking-tight text-slate-900">
            Jurnal Umum Otomatis (General Journal)
          </h1>
          <p className="text-xs text-slate-500 mt-0.5">
            Buku catatan kronologis transaksi berpasangan (Double-Entry). Semua jurnal terverifikasi seimbang.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={exportJournalCsv}
            className="flex items-center gap-1.5 px-3 py-2 text-xs font-medium text-slate-700 bg-white border border-slate-300 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
          >
            <Download className="w-3.5 h-3.5 text-slate-500" />
            <span>Ekspor CSV</span>
          </button>
          <button
            onClick={() => setIsModalOpen(true)}
            className="flex items-center gap-2 px-4 py-2 text-xs font-semibold text-white bg-slate-900 rounded-lg hover:bg-slate-800 transition-colors shadow-xs cursor-pointer"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>Jurnal Penyesuaian</span>
          </button>
        </div>
      </div>

      {/* Filter and Overview */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 bg-white p-3 rounded-xl border border-slate-200">
        <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
          <button
            onClick={() => setFilterType('all')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filterType === 'all' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Semua Jurnal ({journals.length})
          </button>
          <button
            onClick={() => setFilterType('sale')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filterType === 'sale' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Penjualan
          </button>
          <button
            onClick={() => setFilterType('purchase')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filterType === 'purchase' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Pembelian
          </button>
          <button
            onClick={() => setFilterType('depreciation')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filterType === 'depreciation' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Penyusutan
          </button>
          <button
            onClick={() => setFilterType('manual')}
            className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors cursor-pointer ${
              filterType === 'manual' ? 'bg-white text-slate-900 shadow-xs' : 'text-slate-600 hover:text-slate-900'
            }`}
          >
            Penyesuaian Manual
          </button>
        </div>

        <div className="relative">
          <Search className="w-3.5 h-3.5 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            placeholder="Cari no jurnal, akun, keterangan..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-9 pr-3 py-1.5 text-xs border border-slate-300 rounded-lg w-full sm:w-64 focus:ring-1 focus:ring-slate-900 outline-none"
          />
        </div>
      </div>

      {/* Summary Balance Strip */}
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="p-4 bg-white border border-slate-200 rounded-xl">
          <span className="text-xs text-slate-500">Total Akumulasi Debit</span>
          <div className="text-lg font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {formatRupiah(grandTotalDebit)}
          </div>
        </div>
        <div className="p-4 bg-white border border-slate-200 rounded-xl">
          <span className="text-xs text-slate-500">Total Akumulasi Kredit</span>
          <div className="text-lg font-bold font-mono text-slate-900 mt-1 tabular-nums">
            {formatRupiah(grandTotalCredit)}
          </div>
        </div>
        <div className="p-4 bg-white border border-slate-200 rounded-xl flex items-center justify-between">
          <div>
            <span className="text-xs text-slate-500">Status Keseimbangan Buku</span>
            <div className="text-sm font-semibold text-emerald-700 mt-1 flex items-center">
              <CheckCircle2 className="w-4 h-4 mr-1 text-emerald-600" />
              100% Balanced (Debit == Kredit)
            </div>
          </div>
          <span className="text-xs text-slate-400 font-mono">Δ Rp 0</span>
        </div>
      </div>

      {/* Journal Entries List */}
      <div className="space-y-4">
        {filtered.length === 0 ? (
          <div className="bg-white p-12 text-center rounded-xl border border-slate-200 text-slate-500 text-xs">
            Tidak ada ayat jurnal umum yang sesuai dengan filter.
          </div>
        ) : (
          filtered.map((j) => {
            const branch = branches.find(b => b.id === j.branchId);

            return (
              <div key={j.id} className="bg-white rounded-xl border border-slate-200 overflow-hidden shadow-2xs">
                {/* Journal Card Header */}
                <div className="px-5 py-3 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-3 text-xs">
                  <div className="flex items-center gap-3">
                    <span className="font-bold text-slate-900 font-mono">{j.entryNumber}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-600">{formatDate(j.date)}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-600">{branch ? branch.name : 'Pusat'}</span>
                    <span className="text-slate-400">·</span>
                    <span className="text-slate-500 italic truncate max-w-md">{j.description}</span>
                  </div>

                  <div className="flex items-center gap-3">
                    <span className="text-[11px] text-slate-500">Oleh: {j.createdBy}</span>
                    <span className="text-emerald-700 font-medium text-[11px] flex items-center">
                      <CheckCircle2 className="w-3 h-3 mr-0.5" /> Seimbang
                    </span>
                  </div>
                </div>

                {/* Journal Lines Table */}
                <div className="overflow-x-auto">
                  <table className="w-full text-left text-xs">
                    <thead className="text-slate-500 bg-white/60 text-[11px] border-b border-slate-100">
                      <tr>
                        <th className="py-2 px-5 w-32 font-medium">Kode Akun</th>
                        <th className="py-2 px-4 font-medium">Nama Akun & Keterangan</th>
                        <th className="py-2 px-5 text-right w-44 font-medium">Debit (Rp)</th>
                        <th className="py-2 px-5 text-right w-44 font-medium">Kredit (Rp)</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100">
                      {j.lines.map((line, idx) => (
                        <tr key={idx} className="hover:bg-slate-50/50">
                          <td className="py-2.5 px-5 font-mono text-slate-600">
                            {line.accountCode}
                          </td>
                          <td className="py-2.5 px-4">
                            <div className={`text-slate-900 ${line.credit > 0 ? 'pl-6 text-slate-800' : 'font-semibold'}`}>
                              {line.accountName}
                            </div>
                            {line.description && (
                              <div className={`text-[11px] text-slate-400 mt-0.5 ${line.credit > 0 ? 'pl-6' : ''}`}>
                                {line.description}
                              </div>
                            )}
                          </td>
                          <td className="py-2.5 px-5 text-right font-mono tabular-nums text-slate-900">
                            {line.debit > 0 ? formatRupiah(line.debit) : '-'}
                          </td>
                          <td className="py-2.5 px-5 text-right font-mono tabular-nums text-slate-900">
                            {line.credit > 0 ? formatRupiah(line.credit) : '-'}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-slate-50/60 font-semibold border-t border-slate-200">
                      <tr>
                        <td colSpan={2} className="py-2 px-5 text-right text-slate-600">
                          Total Baris Jurnal:
                        </td>
                        <td className="py-2 px-5 text-right font-mono text-slate-900 tabular-nums">
                          {formatRupiah(j.totalDebit)}
                        </td>
                        <td className="py-2 px-5 text-right font-mono text-slate-900 tabular-nums">
                          {formatRupiah(j.totalCredit)}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
              </div>
            );
          })
        )}
      </div>

      {/* Modal Jurnal Penyesuaian Manual */}
      <Modal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        title="Input Jurnal Penyesuaian Manual (Adjusting Entry)"
        subtitle="Digunakan untuk penyesuaian beban akrual, amortisasi, depresiasi khusus, atau koreksi pembukuan."
        maxWidth="3xl"
      >
        <form onSubmit={handleSaveManualJournal} className="space-y-4 text-xs">
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <div>
              <label className="block font-medium text-slate-700 mb-1">Tanggal Jurnal</label>
              <input
                type="date"
                value={formDate}
                onChange={(e) => setFormDate(e.target.value)}
                required
                className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none"
              />
            </div>
            <div>
              <label className="block font-medium text-slate-700 mb-1">Cabang Usaha</label>
              <select
                value={formBranchId}
                onChange={(e) => setFormBranchId(e.target.value)}
                className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none"
              >
                {branches.map(b => (
                  <option key={b.id} value={b.id}>{b.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className="block font-medium text-slate-700 mb-1">Keterangan / Memo Jurnal</label>
            <input
              type="text"
              placeholder="contoh: Penyesuaian biaya asuransi dibayar dimuka Maret 2026"
              value={formDescription}
              onChange={(e) => setFormDescription(e.target.value)}
              required
              className="w-full border border-slate-300 rounded-lg p-2 focus:ring-1 focus:ring-slate-900 outline-none"
            />
          </div>

          {/* Lines */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <span className="font-semibold text-slate-800">Ayat Jurnal (Debit & Kredit)</span>
              <button
                type="button"
                onClick={handleAddLine}
                className="text-slate-900 font-semibold hover:underline cursor-pointer"
              >
                + Tambah Baris Akun
              </button>
            </div>

            <div className="space-y-2">
              {journalLines.map((line, idx) => (
                <div key={idx} className="flex items-center gap-2 bg-slate-50 p-2.5 rounded-lg border border-slate-200">
                  <div className="flex-1">
                    <select
                      value={line.accountCode}
                      onChange={(e) => handleLineChange(idx, 'accountCode', e.target.value)}
                      className="w-full border border-slate-300 rounded-md p-1.5 bg-white outline-none"
                    >
                      {coa.map(c => (
                        <option key={c.code} value={c.code}>
                          {c.code} - {c.name}
                        </option>
                      ))}
                    </select>
                  </div>
                  <div className="w-32">
                    <input
                      type="number"
                      placeholder="Debit (Rp)"
                      value={line.debit || ''}
                      onChange={(e) => handleLineChange(idx, 'debit', Number(e.target.value))}
                      className="w-full border border-slate-300 rounded-md p-1.5 bg-white text-right font-mono outline-none"
                    />
                  </div>
                  <div className="w-32">
                    <input
                      type="number"
                      placeholder="Kredit (Rp)"
                      value={line.credit || ''}
                      onChange={(e) => handleLineChange(idx, 'credit', Number(e.target.value))}
                      className="w-full border border-slate-300 rounded-md p-1.5 bg-white text-right font-mono outline-none"
                    />
                  </div>
                  {journalLines.length > 2 && (
                    <button
                      type="button"
                      onClick={() => handleRemoveLine(idx)}
                      className="p-1 text-slate-400 hover:text-red-600 transition-colors cursor-pointer"
                    >
                      ×
                    </button>
                  )}
                </div>
              ))}
            </div>
          </div>

          {/* Balance Verification Strip */}
          <div className="p-3 bg-slate-100 rounded-lg flex items-center justify-between font-mono text-xs">
            <div>
              Total Debit: <span className="font-bold text-slate-900">{formatRupiah(totalDebitManual)}</span>
            </div>
            <div>
              Total Kredit: <span className="font-bold text-slate-900">{formatRupiah(totalCreditManual)}</span>
            </div>
            <div>
              {isFormBalanced ? (
                <span className="text-emerald-700 font-semibold flex items-center">
                  <CheckCircle2 className="w-4 h-4 mr-1 text-emerald-600" /> Seimbang
                </span>
              ) : (
                <span className="text-amber-800 font-semibold flex items-center">
                  <AlertCircle className="w-4 h-4 mr-1 text-amber-700" /> Selisih {formatRupiah(Math.abs(totalDebitManual - totalCreditManual))}
                </span>
              )}
            </div>
          </div>

          <div className="flex items-center justify-end gap-3 pt-3 border-t border-slate-200">
            <button
              type="button"
              onClick={() => setIsModalOpen(false)}
              className="px-4 py-2 border border-slate-300 text-slate-700 hover:bg-slate-50 rounded-lg transition-colors cursor-pointer"
            >
              Batal
            </button>
            <button
              type="submit"
              disabled={!isFormBalanced}
              className={`px-5 py-2 rounded-lg font-semibold transition-colors cursor-pointer ${
                isFormBalanced
                  ? 'bg-slate-900 hover:bg-slate-800 text-white'
                  : 'bg-slate-300 text-slate-500 cursor-not-allowed'
              }`}
            >
              Posting Jurnal Penyesuaian
            </button>
          </div>
        </form>
      </Modal>
    </div>
  );
};
