export type Role = 'super_admin' | 'branch_manager' | 'accountant' | 'cashier_staff';

export interface User {
  id: string;
  name: string;
  email: string;
  role: Role;
  branchId: string; // 'all' or specific branchId
  avatar?: string;
  phone?: string;
  isActive: boolean;
}

export interface Branch {
  id: string;
  code: string;
  name: string;
  address: string;
  city: string;
  phone: string;
  nitku: string; // Nomor Identitas Tempat Kegiatan Usaha (Format DJP baru)
  managerName: string;
  isActive: boolean;
}

export type AccountCategory = 
  | 'asset_current'
  | 'asset_fixed'
  | 'liability_current'
  | 'liability_long_term'
  | 'equity'
  | 'revenue'
  | 'cogs'
  | 'expense_operational'
  | 'expense_other'
  | 'income_other';

export interface ChartOfAccount {
  code: string;
  name: string;
  category: AccountCategory;
  normalBalance: 'debit' | 'credit';
  balance: number; // Opening/current balance
  description?: string;
}

export type TransactionType = 'sale' | 'purchase' | 'expense';
export type PaymentMethod = 'cash' | 'bank_transfer' | 'credit' | 'qris';

export interface TransactionItem {
  productId?: string;
  productName: string;
  sku?: string;
  qty: number;
  unitPrice: number;
  subtotal: number;
  taxPercent: number; // e.g. 11% or 0
  taxAmount: number;
}

export interface Transaction {
  id: string;
  refNumber: string; // e.g. INV-2026-001
  date: string; // YYYY-MM-DD
  type: TransactionType;
  branchId: string;
  counterpartyName: string; // Customer / Vendor / Beneficiary
  counterpartyNpwp?: string;
  categoryAccountCode: string; // Account Code for expense / revenue / purchase
  paymentAccountCode: string; // Kas (1-1001) or Bank BCA (1-1002) or Hutang/Piutang
  paymentMethod: PaymentMethod;
  paymentStatus: 'paid' | 'partial' | 'unpaid';
  dueDate?: string;
  subtotal: number;
  taxAmount: number;
  taxType?: 'ppn_11' | 'ppn_12' | 'pph_23' | 'pph_final' | 'none';
  totalAmount: number;
  notes?: string;
  items?: TransactionItem[];
  createdAt: string;
  createdBy: string;
}

export interface JournalLine {
  accountCode: string;
  accountName: string;
  debit: number;
  credit: number;
  description?: string;
}

export interface JournalEntry {
  id: string;
  entryNumber: string; // e.g. JU-2026-0301
  date: string;
  referenceType: 'sale' | 'purchase' | 'expense' | 'depreciation' | 'stock_adjustment' | 'manual';
  referenceId?: string;
  branchId: string;
  description: string;
  lines: JournalLine[];
  totalDebit: number;
  totalCredit: number;
  isBalanced: boolean;
  createdAt: string;
  createdBy: string;
}

export interface ProductInventory {
  id: string;
  sku: string;
  barcode: string;
  name: string;
  category: string;
  unit: string; // Pcs, Box, Pack, Unit
  costPrice: number; // HPP Beli
  sellingPrice: number;
  minStockAlert: number;
  stocksByBranch: Record<string, number>; // branchId -> quantity
  description?: string;
}

export interface StockTransfer {
  id: string;
  transferNumber: string;
  date: string;
  fromBranchId: string;
  toBranchId: string;
  items: {
    productId: string;
    productName: string;
    sku: string;
    qty: number;
  }[];
  status: 'draft' | 'in_transit' | 'received' | 'cancelled';
  notes?: string;
  driverOrCourier?: string;
  trackingNo?: string;
  createdAt: string;
  receivedAt?: string;
}

export interface StockOpnameItem {
  productId: string;
  productName: string;
  sku: string;
  systemQty: number;
  physicalQty: number;
  differenceQty: number; // physical - system
  costPrice: number;
  differenceValue: number; // differenceQty * costPrice
  reason?: string;
}

export interface StockOpname {
  id: string;
  opnameNumber: string;
  date: string;
  branchId: string;
  auditorName: string;
  status: 'draft' | 'adjusted' | 'cancelled';
  items: StockOpnameItem[];
  totalDifferenceValue: number;
  notes?: string;
  createdAt: string;
}

export interface FixedAsset {
  id: string;
  code: string;
  name: string;
  category: 'Kendaraan' | 'Peralatan Kantor' | 'Komputer & IT' | 'Gedung & Bangunan' | 'Mesin Produksi';
  branchId: string;
  purchaseDate: string; // YYYY-MM-DD
  acquisitionCost: number; // Harga Perolehan
  salvageValue: number; // Nilai Sisa/Residu
  usefulLifeYears: number; // Masa Manfaat (Tahun)
  depreciationMethod: 'straight_line'; // Garis Lurus
  accumulatedDepreciation: number;
  bookValue: number;
  monthlyDepreciation: number;
  status: 'active' | 'disposed' | 'written_off';
}

export interface EFakturTaxInvoice {
  id: string;
  invoiceNumber: string; // Format e-Faktur: 010.000-26.00000001
  nsfp: string;
  date: string;
  type: 'keluaran' | 'masukan';
  customerVendorName: string;
  npwp: string; // 16 digit format baru
  nik?: string;
  address: string;
  dpp: number; // Dasar Pengenaan Pajak
  ppnRate: number; // 11% or 12%
  ppnAmount: number;
  ppnbm: number;
  statusDjp: 'siap_upload' | 'approval_sukses' | 'ditolak_djp' | 'batal';
  qrCodeUrl?: string;
  referensiTransaksiId?: string;
  createdAt: string;
}
