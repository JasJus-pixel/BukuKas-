export function formatRupiah(value: number): string {
  return new Intl.NumberFormat('id-ID', {
    style: 'currency',
    currency: 'IDR',
    maximumFractionDigits: 0,
  }).format(value || 0);
}

export function formatNumber(value: number): string {
  return new Intl.NumberFormat('id-ID').format(value || 0);
}

export function formatDate(dateString: string): string {
  if (!dateString) return '-';
  try {
    const date = new Date(dateString);
    return date.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
    });
  } catch {
    return dateString;
  }
}

export function formatDateTime(dateTimeString: string): string {
  if (!dateTimeString) return '-';
  try {
    const date = new Date(dateTimeString);
    return date.toLocaleDateString('id-ID', {
      day: 'numeric',
      month: 'short',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
    });
  } catch {
    return dateTimeString;
  }
}

/**
 * Validates Indonesian NPWP (15 or 16 digit format)
 */
export function validateNpwp(npwp: string): { isValid: boolean; message: string; formatted: string } {
  const clean = npwp.replace(/[^0-9]/g, '');
  if (clean.length === 15) {
    // 15 digits format: 01.234.567.8-901.000
    const formatted = `${clean.slice(0, 2)}.${clean.slice(2, 5)}.${clean.slice(5, 8)}.${clean.slice(8, 9)}-${clean.slice(9, 12)}.${clean.slice(12, 15)}`;
    return { isValid: true, message: 'NPWP 15 Digit Valid (Konversi ke NIK/NPWP 16 Disarankan)', formatted };
  } else if (clean.length === 16) {
    // 16 digits format baru DJP / NIK terintegrasi
    const formatted = `${clean.slice(0, 2)}.${clean.slice(2, 5)}.${clean.slice(5, 8)}.${clean.slice(8, 9)}-${clean.slice(9, 12)}.${clean.slice(12, 16)}`;
    return { isValid: true, message: 'NPWP 16 Digit Format Baru DJP Valid & Terdaftar di PJAP', formatted };
  } else {
    return { isValid: false, message: 'NPWP harus berjumlah 15 atau 16 digit angka', formatted: npwp };
  }
}

/**
 * Generate official e-Faktur DJP Import CSV string format
 * Compliant with DJP Desktop e-Faktur specification (FK, LT, OF rows)
 */
export function generateEfakturDjpCsv(invoices: any[]): string {
  const lines: string[] = [];
  
  // Header FK (Faktur Pajak Keluaran)
  lines.push('FK,KD_JENIS_TRANSAKSI,FG_PENGGANTI,NOMOR_FAKTUR,MASA_PAJAK,TAHUN_PAJAK,TANGGAL_FAKTUR,NPWP,NAMA,ALAMAT_LENGKAP,JUMLAH_DPP,JUMLAH_PPN,JUMLAH_PPNBM,ID_KETERANGAN_TAMBAHAN,FG_UANG_MUKA,UANG_MUKA_DPP,UANG_MUKA_PPN,UANG_MUKA_PPNBM,REFERENSI');
  lines.push('LT,NPWP,NAMA,JALAN,BLOK,NOMOR,RT,RW,KECAMATAN,KELURAHAN,KABUPATEN,PROPINSI,KODE_POS,NOMOR_TELEPON');
  lines.push('OF,KODE_OBJEK,NAMA,HARGA_SATUAN,JUMLAH_BARANG,HARGA_TOTAL,DISKON,DPP,PPN,TARIF_PPNBM,PPNBM');

  invoices.forEach(inv => {
    const rawFaktur = (inv.invoiceNumber || '010.000-26.00000001').replace(/[^0-9]/g, '');
    const cleanNpwp = (inv.npwp || '0000000000000000').replace(/[^0-9]/g, '');
    const dateParts = (inv.date || '2026-03-01').split('-');
    const formattedDate = `${dateParts[2]}/${dateParts[1]}/${dateParts[0]}`;
    const masaPajak = parseInt(dateParts[1], 10) || 3;
    const tahunPajak = dateParts[0] || '2026';

    // Baris FK
    lines.push(`FK,01,0,${rawFaktur},${masaPajak},${tahunPajak},${formattedDate},${cleanNpwp},"${inv.customerVendorName || 'Konsumen'}","${inv.address || 'Indonesia'}",${inv.dpp},${inv.ppnAmount},0,,0,0,0,0,"${inv.referensiTransaksiId || 'BukuKas Pro'}"`);
    
    // Baris OF (Objek Faktur)
    lines.push(`OF,000000,"Barang/Jasa Kena Pajak Terlampir",${inv.dpp},1,${inv.dpp},0,${inv.dpp},${inv.ppnAmount},0,0`);
  });

  return lines.join('\r\n');
}

/**
 * Generate sample DJP XML Schema for web-efaktur.pajak.go.id
 */
export function generateEfakturXml(invoices: any[]): string {
  const xmlItems = invoices.map(inv => `
    <fakturKeluaran>
      <nomorFaktur>${inv.invoiceNumber}</nomorFaktur>
      <tanggalFaktur>${inv.date}</tanggalFaktur>
      <npwpLawanTransaksi>${inv.npwp}</npwpLawanTransaksi>
      <namaLawanTransaksi><![CDATA[${inv.customerVendorName}]]></namaLawanTransaksi>
      <dpp>${inv.dpp}</dpp>
      <ppn>${inv.ppnAmount}</ppn>
      <tarifPpn>${inv.ppnRate}%</tarifPpn>
      <statusDjp>${inv.statusDjp}</statusDjp>
      <nsfp>${inv.nsfp}</nsfp>
    </fakturKeluaran>`).join('');

  return `<?xml version="1.0" encoding="UTF-8"?>
<resValidateFakturPm xmlns="http://pjap.pajak.go.id/schema/efaktur">
  <generatedAt>${new Date().toISOString()}</generatedAt>
  <totalFaktur>${invoices.length}</totalFaktur>
  <daftarFaktur>${xmlItems}
  </daftarFaktur>
</resValidateFakturPm>`;
}
