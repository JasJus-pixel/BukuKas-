import React, { createContext, useContext, useState, useEffect } from 'react';
import {
  Branch,
  User,
  ChartOfAccount,
  ProductInventory,
  Transaction,
  JournalEntry,
  FixedAsset,
  EFakturTaxInvoice,
  StockTransfer,
  StockOpname,
  Role,
  TransactionItem
} from '../types/accounting';
import {
  INITIAL_BRANCHES,
  INITIAL_USERS,
  INITIAL_COA,
  INITIAL_PRODUCTS,
  INITIAL_TRANSACTIONS,
  INITIAL_JOURNALS,
  INITIAL_FIXED_ASSETS,
  INITIAL_EFAKTUR,
  INITIAL_STOCK_TRANSFERS,
  INITIAL_STOCK_OPNAMES,
} from '../data/initialData';

interface AppContextType {
  // User & Role
  currentUser: User;
  setCurrentUser: (user: User) => void;
  switchUserRole: (role: Role) => void;
  users: User[];
  addUser: (user: Omit<User, 'id'>) => void;

  // Branch
  branches: Branch[];
  activeBranchId: string; // 'all' or branchId
  setActiveBranchId: (branchId: string) => void;
  addBranch: (branch: Omit<Branch, 'id'>) => void;
  getActiveBranchName: () => string;

  // COA & Accounting
  coa: ChartOfAccount[];
  transactions: Transaction[];
  journals: JournalEntry[];
  addTransaction: (txData: Omit<Transaction, 'id' | 'createdAt' | 'refNumber'>) => void;
  addManualJournal: (journal: Omit<JournalEntry, 'id' | 'createdAt' | 'entryNumber' | 'isBalanced'>) => boolean;

  // Inventory & Stock
  products: ProductInventory[];
  addProduct: (product: Omit<ProductInventory, 'id'>) => void;
  stockTransfers: StockTransfer[];
  createStockTransfer: (transfer: Omit<StockTransfer, 'id' | 'transferNumber' | 'createdAt' | 'status'>) => void;
  receiveStockTransfer: (transferId: string) => void;
  stockOpnames: StockOpname[];
  createStockOpname: (opname: Omit<StockOpname, 'id' | 'opnameNumber' | 'createdAt' | 'status'>) => void;

  // Fixed Assets
  fixedAssets: FixedAsset[];
  addFixedAsset: (asset: Omit<FixedAsset, 'id' | 'accumulatedDepreciation' | 'bookValue' | 'monthlyDepreciation'>) => void;
  runMonthlyDepreciation: () => { totalDepreciated: number; journalNumber: string };

  // Tax & e-Faktur DJP
  eFakturs: EFakturTaxInvoice[];
  addEfaktur: (efaktur: Omit<EFakturTaxInvoice, 'id' | 'invoiceNumber' | 'nsfp' | 'createdAt'>) => void;
  approveEfakturDjp: (id: string) => void;
  batchApproveEfaktur: () => void;

  // Financial Report Computation Helpers
  getFinancialSummary: () => {
    totalRevenue: number;
    totalCogs: number;
    grossProfit: number;
    totalExpense: number;
    netProfit: number;
    totalCurrentAssets: number;
    totalFixedAssets: number;
    totalAssets: number;
    totalLiabilities: number;
    totalEquity: number;
    cashAndBank: number;
    inventoryValue: number;
    arBalance: number;
    apBalance: number;
    unpaidVat: number;
  };
  
  // Reset Data to Initial
  resetToDefaultData: () => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  // Persistence initialization
  const loadStored = <T,>(key: string, fallback: T): T => {
    try {
      const item = localStorage.getItem(`bukukas_${key}`);
      return item ? JSON.parse(item) : fallback;
    } catch {
      return fallback;
    }
  };

  const [branches, setBranches] = useState<Branch[]>(() => loadStored('branches', INITIAL_BRANCHES));
  const [users, setUsers] = useState<User[]>(() => loadStored('users', INITIAL_USERS));
  const [currentUser, setCurrentUser] = useState<User>(() => {
    const storedUsers = loadStored('users', INITIAL_USERS);
    return storedUsers[0] || INITIAL_USERS[0];
  });
  const [activeBranchId, setActiveBranchId] = useState<string>('all');

  const [coa, setCoa] = useState<ChartOfAccount[]>(() => loadStored('coa', INITIAL_COA));
  const [products, setProducts] = useState<ProductInventory[]>(() => loadStored('products', INITIAL_PRODUCTS));
  const [transactions, setTransactions] = useState<Transaction[]>(() => loadStored('transactions', INITIAL_TRANSACTIONS));
  const [journals, setJournals] = useState<JournalEntry[]>(() => loadStored('journals', INITIAL_JOURNALS));
  const [fixedAssets, setFixedAssets] = useState<FixedAsset[]>(() => loadStored('fixed_assets', INITIAL_FIXED_ASSETS));
  const [eFakturs, setEFakturs] = useState<EFakturTaxInvoice[]>(() => loadStored('efakturs', INITIAL_EFAKTUR));
  const [stockTransfers, setStockTransfers] = useState<StockTransfer[]>(() => loadStored('stock_transfers', INITIAL_STOCK_TRANSFERS));
  const [stockOpnames, setStockOpnames] = useState<StockOpname[]>(() => loadStored('stock_opnames', INITIAL_STOCK_OPNAMES));

  // Sync to local storage
  useEffect(() => { localStorage.setItem('bukukas_branches', JSON.stringify(branches)); }, [branches]);
  useEffect(() => { localStorage.setItem('bukukas_users', JSON.stringify(users)); }, [users]);
  useEffect(() => { localStorage.setItem('bukukas_coa', JSON.stringify(coa)); }, [coa]);
  useEffect(() => { localStorage.setItem('bukukas_products', JSON.stringify(products)); }, [products]);
  useEffect(() => { localStorage.setItem('bukukas_transactions', JSON.stringify(transactions)); }, [transactions]);
  useEffect(() => { localStorage.setItem('bukukas_journals', JSON.stringify(journals)); }, [journals]);
  useEffect(() => { localStorage.setItem('bukukas_fixed_assets', JSON.stringify(fixedAssets)); }, [fixedAssets]);
  useEffect(() => { localStorage.setItem('bukukas_efakturs', JSON.stringify(eFakturs)); }, [eFakturs]);
  useEffect(() => { localStorage.setItem('bukukas_stock_transfers', JSON.stringify(stockTransfers)); }, [stockTransfers]);
  useEffect(() => { localStorage.setItem('bukukas_stock_opnames', JSON.stringify(stockOpnames)); }, [stockOpnames]);

  const switchUserRole = (role: Role) => {
    const existing = users.find(u => u.role === role);
    if (existing) {
      setCurrentUser(existing);
    } else {
      setCurrentUser(prev => ({ ...prev, role }));
    }
  };

  const getActiveBranchName = () => {
    if (activeBranchId === 'all') return 'Semua Cabang (Konsolidasian)';
    const found = branches.find(b => b.id === activeBranchId);
    return found ? found.name : 'Cabang Terpilih';
  };

  const addBranch = (newBranchData: Omit<Branch, 'id'>) => {
    const newBranch: Branch = {
      ...newBranchData,
      id: `br-${Date.now().toString().slice(-4)}`,
    };
    setBranches(prev => [...prev, newBranch]);
    // Initialize stock of 0 for products in new branch
    setProducts(prev => prev.map(p => ({
      ...p,
      stocksByBranch: {
        ...p.stocksByBranch,
        [newBranch.id]: 0,
      }
    })));
  };

  const addUser = (userData: Omit<User, 'id'>) => {
    const newUser: User = {
      ...userData,
      id: `usr-${Date.now().toString().slice(-4)}`,
    };
    setUsers(prev => [...prev, newUser]);
  };

  // Add a transaction with AUTOMATED DOUBLE-ENTRY JOURNAL and INVENTORY UPDATES!
  const addTransaction = (txData: Omit<Transaction, 'id' | 'createdAt' | 'refNumber'>) => {
    const now = new Date();
    const dateStr = txData.date || now.toISOString().split('T')[0];
    const prefix = txData.type === 'sale' ? 'INV' : txData.type === 'purchase' ? 'PO' : 'BKK';
    const refNumber = `${prefix}/${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(transactions.length + 1).padStart(3, '0')}`;
    const txId = `trx-${Date.now()}`;

    const newTx: Transaction = {
      ...txData,
      id: txId,
      refNumber,
      createdAt: now.toLocaleString('id-ID'),
    };

    setTransactions(prev => [newTx, ...prev]);

    // Build automated journal entry
    const journalNumber = `JU/${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(journals.length + 1).padStart(3, '0')}`;
    const journalLines: any[] = [];
    let totalDebit = 0;
    let totalCredit = 0;

    // Helper to add line
    const addLine = (accountCode: string, debit: number, credit: number, desc?: string) => {
      const coaItem = coa.find(c => c.code === accountCode);
      const accountName = coaItem ? coaItem.name : accountCode;
      journalLines.push({
        accountCode,
        accountName,
        debit,
        credit,
        description: desc || '',
      });
      totalDebit += debit;
      totalCredit += credit;
    };

    if (txData.type === 'sale') {
      // 1. Debit Kas/Bank or Piutang
      const receivingAccount = txData.paymentStatus === 'paid' ? txData.paymentAccountCode : '1-1004'; // Piutang Usaha
      addLine(receivingAccount, txData.totalAmount, 0, `Penerimaan penjualan ${refNumber}`);

      // 2. Credit Pendapatan Penjualan
      addLine(txData.categoryAccountCode || '4-1001', 0, txData.subtotal, `Pendapatan penjualan ${newTx.counterpartyName}`);

      // 3. Credit PPN Keluaran jika ada pajak
      if (txData.taxAmount > 0) {
        addLine('2-1002', 0, txData.taxAmount, `Hutang PPN Keluaran 11%`);
      }

      // 4. Hitung HPP dan kurangi persediaan jika ada item produk
      let totalCogs = 0;
      if (txData.items && txData.items.length > 0) {
        txData.items.forEach(item => {
          if (item.productId) {
            const product = products.find(p => p.id === item.productId);
            const cost = product ? product.costPrice * item.qty : item.unitPrice * 0.7 * item.qty;
            totalCogs += cost;

            // Deduct stock in branch
            setProducts(currentProducts => currentProducts.map(p => {
              if (p.id === item.productId) {
                const currentStock = p.stocksByBranch[txData.branchId] || 0;
                return {
                  ...p,
                  stocksByBranch: {
                    ...p.stocksByBranch,
                    [txData.branchId]: Math.max(0, currentStock - item.qty),
                  }
                };
              }
              return p;
            }));
          }
        });

        if (totalCogs > 0) {
          addLine('5-1001', totalCogs, 0, `HPP produk terjual ${refNumber}`);
          addLine('1-1005', 0, totalCogs, `Pengurangan persediaan barang gudang`);
        }
      }

      // 5. Generate e-Faktur Keluaran otomatis jika PPN aktif
      if (txData.taxAmount > 0) {
        const nsfpSeq = String(eFakturs.length + 101).padStart(8, '0');
        const efaktur: EFakturTaxInvoice = {
          id: `efk-${Date.now()}`,
          invoiceNumber: `010.000-26.${nsfpSeq}`,
          nsfp: nsfpSeq,
          date: dateStr,
          type: 'keluaran',
          customerVendorName: txData.counterpartyName,
          npwp: (txData.counterpartyNpwp || '0123456789010000').replace(/[^0-9]/g, ''),
          address: 'Alamat Lawan Transaksi, Indonesia',
          dpp: txData.subtotal,
          ppnRate: txData.taxType === 'ppn_12' ? 12 : 11,
          ppnAmount: txData.taxAmount,
          ppnbm: 0,
          statusDjp: 'siap_upload',
          referensiTransaksiId: refNumber,
          createdAt: now.toLocaleString('id-ID'),
        };
        setEFakturs(prev => [efaktur, ...prev]);
      }

    } else if (txData.type === 'purchase') {
      // 1. Debit Persediaan Barang Dagang
      addLine(txData.categoryAccountCode || '1-1005', txData.subtotal, 0, `Pembelian barang ${refNumber}`);

      // 2. Debit PPN Masukan jika ada pajak
      if (txData.taxAmount > 0) {
        addLine('1-1006', txData.taxAmount, 0, `PPN Masukan dibayar dimuka`);
      }

      // 3. Credit Kas/Bank or Hutang Usaha
      const payingAccount = txData.paymentStatus === 'paid' ? txData.paymentAccountCode : '2-1001'; // Hutang Usaha
      addLine(payingAccount, 0, txData.totalAmount, `Kewajiban pembelian ${newTx.counterpartyName}`);

      // Tambahkan stok produk ke gudang cabang
      if (txData.items && txData.items.length > 0) {
        txData.items.forEach(item => {
          if (item.productId) {
            setProducts(currentProducts => currentProducts.map(p => {
              if (p.id === item.productId) {
                const currentStock = p.stocksByBranch[txData.branchId] || 0;
                return {
                  ...p,
                  stocksByBranch: {
                    ...p.stocksByBranch,
                    [txData.branchId]: currentStock + item.qty,
                  }
                };
              }
              return p;
            }));
          }
        });
      }

      // Generate e-Faktur Masukan jika PPN aktif
      if (txData.taxAmount > 0) {
        const nsfpSeq = String(eFakturs.length + 89200000).padStart(8, '0');
        const efaktur: EFakturTaxInvoice = {
          id: `efk-${Date.now()}`,
          invoiceNumber: `010.000-26.${nsfpSeq}`,
          nsfp: nsfpSeq,
          date: dateStr,
          type: 'masukan',
          customerVendorName: txData.counterpartyName,
          npwp: (txData.counterpartyNpwp || '0188899910540000').replace(/[^0-9]/g, ''),
          address: 'Alamat Supplier, Indonesia',
          dpp: txData.subtotal,
          ppnRate: 11,
          ppnAmount: txData.taxAmount,
          ppnbm: 0,
          statusDjp: 'approval_sukses',
          referensiTransaksiId: refNumber,
          createdAt: now.toLocaleString('id-ID'),
        };
        setEFakturs(prev => [efaktur, ...prev]);
      }

    } else if (txData.type === 'expense') {
      // 1. Debit Akun Beban
      addLine(txData.categoryAccountCode, txData.subtotal, 0, `Beban ${txData.notes || refNumber}`);

      // 2. Jika ada PPh 23 (Potongan 2%)
      if (txData.taxType === 'pph_23' && txData.taxAmount > 0) {
        addLine('2-1003', 0, txData.taxAmount, `Hutang PPh 23 tarif 2% dipotong`);
        addLine(txData.paymentAccountCode, 0, txData.totalAmount, `Pembayaran kas/bank netto setelah PPh 23`);
      } else {
        // Pembayaran beban biasa
        addLine(txData.paymentAccountCode, 0, txData.totalAmount, `Pembayaran kas/bank ${refNumber}`);
      }
    }

    const autoJournal: JournalEntry = {
      id: `ju-${Date.now()}`,
      entryNumber: journalNumber,
      date: dateStr,
      referenceType: txData.type,
      referenceId: newTx.id,
      branchId: txData.branchId,
      description: `Otomatis: ${txData.notes || `${txData.type.toUpperCase()} ${refNumber} (${txData.counterpartyName})`}`,
      lines: journalLines,
      totalDebit,
      totalCredit,
      isBalanced: totalDebit === totalCredit,
      createdAt: now.toLocaleString('id-ID'),
      createdBy: 'Sistem Pembukuan Otomatis',
    };

    setJournals(prev => [autoJournal, ...prev]);
  };

  const addManualJournal = (journalData: Omit<JournalEntry, 'id' | 'createdAt' | 'entryNumber' | 'isBalanced'>): boolean => {
    if (journalData.totalDebit !== journalData.totalCredit) {
      return false;
    }
    const now = new Date();
    const entryNumber = `JU/${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(journals.length + 1).padStart(3, '0')}`;
    const newJournal: JournalEntry = {
      ...journalData,
      id: `ju-${Date.now()}`,
      entryNumber,
      isBalanced: true,
      createdAt: now.toLocaleString('id-ID'),
    };
    setJournals(prev => [newJournal, ...prev]);
    return true;
  };

  const addProduct = (prodData: Omit<ProductInventory, 'id'>) => {
    const newProduct: ProductInventory = {
      ...prodData,
      id: `prd-${Date.now().toString().slice(-4)}`,
    };
    setProducts(prev => [newProduct, ...prev]);
  };

  const createStockTransfer = (transferData: Omit<StockTransfer, 'id' | 'transferNumber' | 'createdAt' | 'status'>) => {
    const now = new Date();
    const transferNumber = `MUT/${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(stockTransfers.length + 1).padStart(3, '0')}`;
    const newTransfer: StockTransfer = {
      ...transferData,
      id: `trf-${Date.now()}`,
      transferNumber,
      status: 'in_transit',
      createdAt: now.toLocaleString('id-ID'),
    };

    // Deduct stock from source branch immediately upon shipping
    setProducts(currentProducts => currentProducts.map(p => {
      const itemToMove = transferData.items.find(i => i.productId === p.id);
      if (itemToMove) {
        const currentSrcStock = p.stocksByBranch[transferData.fromBranchId] || 0;
        return {
          ...p,
          stocksByBranch: {
            ...p.stocksByBranch,
            [transferData.fromBranchId]: Math.max(0, currentSrcStock - itemToMove.qty),
          }
        };
      }
      return p;
    }));

    setStockTransfers(prev => [newTransfer, ...prev]);
  };

  const receiveStockTransfer = (transferId: string) => {
    const transfer = stockTransfers.find(t => t.id === transferId);
    if (!transfer || transfer.status === 'received') return;

    // Add stock to target branch
    setProducts(currentProducts => currentProducts.map(p => {
      const itemToReceive = transfer.items.find(i => i.productId === p.id);
      if (itemToReceive) {
        const currentDestStock = p.stocksByBranch[transfer.toBranchId] || 0;
        return {
          ...p,
          stocksByBranch: {
            ...p.stocksByBranch,
            [transfer.toBranchId]: currentDestStock + itemToReceive.qty,
          }
        };
      }
      return p;
    }));

    setStockTransfers(prev => prev.map(t => {
      if (t.id === transferId) {
        return {
          ...t,
          status: 'received',
          receivedAt: new Date().toLocaleString('id-ID'),
        };
      }
      return t;
    }));
  };

  const createStockOpname = (opnameData: Omit<StockOpname, 'id' | 'opnameNumber' | 'createdAt' | 'status'>) => {
    const now = new Date();
    const opnameNumber = `SO/${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(stockOpnames.length + 1).padStart(3, '0')}`;
    const newOpname: StockOpname = {
      ...opnameData,
      id: `opn-${Date.now()}`,
      opnameNumber,
      status: 'adjusted',
      createdAt: now.toLocaleString('id-ID'),
    };

    // Apply adjustments to product stock in branch
    setProducts(currentProducts => currentProducts.map(p => {
      const itemAdjusted = opnameData.items.find(i => i.productId === p.id);
      if (itemAdjusted) {
        return {
          ...p,
          stocksByBranch: {
            ...p.stocksByBranch,
            [opnameData.branchId]: itemAdjusted.physicalQty,
          }
        };
      }
      return p;
    }));

    // If there is difference value, post automated journal entry
    if (opnameData.totalDifferenceValue !== 0) {
      const diffVal = Math.abs(opnameData.totalDifferenceValue);
      const journalNumber = `JU/${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(journals.length + 1).padStart(3, '0')}`;
      
      const lines = opnameData.totalDifferenceValue < 0 ? [
        { accountCode: '6-1005', accountName: 'Beban Penyesuaian Selisih Stok', debit: diffVal, credit: 0, description: `Selisih kurang fisik ${opnameNumber}` },
        { accountCode: '1-1005', accountName: 'Persediaan Barang Dagang', debit: 0, credit: diffVal, description: `Penyesuaian stok opname ${opnameNumber}` },
      ] : [
        { accountCode: '1-1005', accountName: 'Persediaan Barang Dagang', debit: diffVal, credit: 0, description: `Penyesuaian stok fisik lebih ${opnameNumber}` },
        { accountCode: '4-2001', accountName: 'Pendapatan Lain-lain (Surplus Stok)', debit: 0, credit: diffVal, description: `Surplus stok opname ${opnameNumber}` },
      ];

      const opnameJournal: JournalEntry = {
        id: `ju-${Date.now()}`,
        entryNumber: journalNumber,
        date: opnameData.date,
        referenceType: 'stock_adjustment',
        referenceId: newOpname.id,
        branchId: opnameData.branchId,
        description: `Penyesuaian Stok Opname ${opnameNumber} (${getActiveBranchName()})`,
        lines,
        totalDebit: diffVal,
        totalCredit: diffVal,
        isBalanced: true,
        createdAt: now.toLocaleString('id-ID'),
        createdBy: 'Sistem Stok Opname Otomatis',
      };
      setJournals(prev => [opnameJournal, ...prev]);
    }

    setStockOpnames(prev => [newOpname, ...prev]);
  };

  const addFixedAsset = (assetData: Omit<FixedAsset, 'id' | 'accumulatedDepreciation' | 'bookValue' | 'monthlyDepreciation'>) => {
    const usefulMonths = assetData.usefulLifeYears * 12;
    const depreciableAmount = assetData.acquisitionCost - assetData.salvageValue;
    const monthlyDepreciation = Math.round(depreciableAmount / usefulMonths);
    const newAsset: FixedAsset = {
      ...assetData,
      id: `ast-${Date.now().toString().slice(-4)}`,
      monthlyDepreciation,
      accumulatedDepreciation: 0,
      bookValue: assetData.acquisitionCost,
    };
    setFixedAssets(prev => [newAsset, ...prev]);
  };

  const runMonthlyDepreciation = () => {
    let totalMonthlyDep = 0;
    const updatedAssets = fixedAssets.map(asset => {
      if (asset.status !== 'active') return asset;
      const newAccumulated = Math.min(
        asset.acquisitionCost - asset.salvageValue,
        asset.accumulatedDepreciation + asset.monthlyDepreciation
      );
      const newBookValue = Math.max(asset.salvageValue, asset.acquisitionCost - newAccumulated);
      totalMonthlyDep += asset.monthlyDepreciation;
      return {
        ...asset,
        accumulatedDepreciation: newAccumulated,
        bookValue: newBookValue,
      };
    });

    setFixedAssets(updatedAssets);

    // Auto-generate depreciation journal entry
    const now = new Date();
    const journalNumber = `JU/${now.getFullYear()}/${String(now.getMonth() + 1).padStart(2, '0')}/${String(journals.length + 1).padStart(3, '0')}`;
    const depJournal: JournalEntry = {
      id: `ju-${Date.now()}`,
      entryNumber: journalNumber,
      date: now.toISOString().split('T')[0],
      referenceType: 'depreciation',
      branchId: activeBranchId === 'all' ? 'br-jkt' : activeBranchId,
      description: `Beban Penyusutan Aset Tetap Periode Bulanan (${now.toLocaleDateString('id-ID', { month: 'long', year: 'numeric' })})`,
      lines: [
        { accountCode: '6-1006', accountName: 'Beban Penyusutan Aset Tetap', debit: totalMonthlyDep, credit: 0, description: 'Penyusutan bulanan seluruh aset aktif' },
        { accountCode: '1-2003', accountName: 'Akumulasi Penyusutan Kendaraan & Aset Tetap', debit: 0, credit: totalMonthlyDep, description: 'Alokasi akumulasi depresiasi' },
      ],
      totalDebit: totalMonthlyDep,
      totalCredit: totalMonthlyDep,
      isBalanced: true,
      createdAt: now.toLocaleString('id-ID'),
      createdBy: 'Sistem Depresiasi Otomatis',
    };

    setJournals(prev => [depJournal, ...prev]);
    return { totalDepreciated: totalMonthlyDep, journalNumber };
  };

  const addEfaktur = (efData: Omit<EFakturTaxInvoice, 'id' | 'invoiceNumber' | 'nsfp' | 'createdAt'>) => {
    const nsfpSeq = String(eFakturs.length + 101).padStart(8, '0');
    const newEfaktur: EFakturTaxInvoice = {
      ...efData,
      id: `efk-${Date.now()}`,
      invoiceNumber: `010.000-26.${nsfpSeq}`,
      nsfp: nsfpSeq,
      createdAt: new Date().toLocaleString('id-ID'),
    };
    setEFakturs(prev => [newEfaktur, ...prev]);
  };

  const approveEfakturDjp = (id: string) => {
    setEFakturs(prev => prev.map(inv => {
      if (inv.id === id) {
        return {
          ...inv,
          statusDjp: 'approval_sukses',
          qrCodeUrl: `https://efaktur.pajak.go.id/validasi/${inv.invoiceNumber.replace(/[^0-9]/g, '')}`,
        };
      }
      return inv;
    }));
  };

  const batchApproveEfaktur = () => {
    setEFakturs(prev => prev.map(inv => {
      if (inv.statusDjp === 'siap_upload') {
        return {
          ...inv,
          statusDjp: 'approval_sukses',
          qrCodeUrl: `https://efaktur.pajak.go.id/validasi/${inv.invoiceNumber.replace(/[^0-9]/g, '')}`,
        };
      }
      return inv;
    }));
  };

  const getFinancialSummary = () => {
    // Filter transactions and journals by active branch if not 'all'
    const filteredTx = activeBranchId === 'all' 
      ? transactions 
      : transactions.filter(t => t.branchId === activeBranchId);

    const totalRevenue = filteredTx
      .filter(t => t.type === 'sale')
      .reduce((sum, t) => sum + t.subtotal, 0);

    const totalExpense = filteredTx
      .filter(t => t.type === 'expense')
      .reduce((sum, t) => sum + t.subtotal, 0);

    // Calculate COGS
    let totalCogs = 0;
    filteredTx
      .filter(t => t.type === 'sale')
      .forEach(t => {
        if (t.items && t.items.length > 0) {
          t.items.forEach(i => {
            const prd = products.find(p => p.id === i.productId);
            totalCogs += (prd ? prd.costPrice : i.unitPrice * 0.7) * i.qty;
          });
        }
      });

    const grossProfit = totalRevenue - totalCogs;
    const netProfit = grossProfit - totalExpense;

    // Total Inventory Value
    let inventoryValue = 0;
    products.forEach(p => {
      const stock = activeBranchId === 'all' 
        ? Object.values(p.stocksByBranch).reduce((a, b) => a + b, 0)
        : (p.stocksByBranch[activeBranchId] || 0);
      inventoryValue += stock * p.costPrice;
    });

    // Fixed Assets Book Value
    const filteredAssets = activeBranchId === 'all'
      ? fixedAssets
      : fixedAssets.filter(a => a.branchId === activeBranchId);
    const totalFixedAssets = filteredAssets.reduce((sum, a) => sum + a.bookValue, 0);

    // Accounts Receivable and Payable
    const arBalance = filteredTx
      .filter(t => t.type === 'sale' && t.paymentStatus !== 'paid')
      .reduce((sum, t) => sum + t.totalAmount, 0);

    const apBalance = filteredTx
      .filter(t => t.type === 'purchase' && t.paymentStatus !== 'paid')
      .reduce((sum, t) => sum + t.totalAmount, 0);

    // Cash and Bank estimate
    const cashAndBank = coa
      .filter(c => c.code === '1-1001' || c.code === '1-1002' || c.code === '1-1003')
      .reduce((sum, c) => sum + c.balance, 0);

    const totalCurrentAssets = cashAndBank + arBalance + inventoryValue;
    const totalAssets = totalCurrentAssets + totalFixedAssets;
    const totalLiabilities = apBalance + 350000000 + 48600000;
    const totalEquity = totalAssets - totalLiabilities;

    // Unpaid VAT (PPN Keluaran - PPN Masukan)
    const vatOut = eFakturs
      .filter(ef => ef.type === 'keluaran')
      .reduce((sum, ef) => sum + ef.ppnAmount, 0);
    const vatIn = eFakturs
      .filter(ef => ef.type === 'masukan')
      .reduce((sum, ef) => sum + ef.ppnAmount, 0);
    const unpaidVat = Math.max(0, vatOut - vatIn);

    return {
      totalRevenue,
      totalCogs,
      grossProfit,
      totalExpense,
      netProfit,
      totalCurrentAssets,
      totalFixedAssets,
      totalAssets,
      totalLiabilities,
      totalEquity,
      cashAndBank,
      inventoryValue,
      arBalance,
      apBalance,
      unpaidVat,
    };
  };

  const resetToDefaultData = () => {
    localStorage.clear();
    setBranches(INITIAL_BRANCHES);
    setUsers(INITIAL_USERS);
    setCurrentUser(INITIAL_USERS[0]);
    setActiveBranchId('all');
    setCoa(INITIAL_COA);
    setProducts(INITIAL_PRODUCTS);
    setTransactions(INITIAL_TRANSACTIONS);
    setJournals(INITIAL_JOURNALS);
    setFixedAssets(INITIAL_FIXED_ASSETS);
    setEFakturs(INITIAL_EFAKTUR);
    setStockTransfers(INITIAL_STOCK_TRANSFERS);
    setStockOpnames(INITIAL_STOCK_OPNAMES);
  };

  return (
    <AppContext.Provider
      value={{
        currentUser,
        setCurrentUser,
        switchUserRole,
        users,
        addUser,
        branches,
        activeBranchId,
        setActiveBranchId,
        addBranch,
        getActiveBranchName,
        coa,
        transactions,
        journals,
        addTransaction,
        addManualJournal,
        products,
        addProduct,
        stockTransfers,
        createStockTransfer,
        receiveStockTransfer,
        stockOpnames,
        createStockOpname,
        fixedAssets,
        addFixedAsset,
        runMonthlyDepreciation,
        eFakturs,
        addEfaktur,
        approveEfakturDjp,
        batchApproveEfaktur,
        getFinancialSummary,
        resetToDefaultData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
};

export const useApp = () => {
  const context = useContext(AppContext);
  if (!context) {
    throw new Error('useApp must be used within an AppProvider');
  }
  return context;
};
