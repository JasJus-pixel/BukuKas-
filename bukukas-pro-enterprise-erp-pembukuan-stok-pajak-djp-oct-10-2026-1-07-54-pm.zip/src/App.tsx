/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { AppProvider, useApp } from './context/AppContext';
import { Header } from './components/layout/Header';
import { Sidebar } from './components/layout/Sidebar';
import { DashboardView } from './components/dashboard/DashboardView';
import { TransactionsView } from './components/accounting/TransactionsView';
import { JournalView } from './components/accounting/JournalView';
import { FinancialReportsView } from './components/accounting/FinancialReportsView';
import { InventoryView } from './components/inventory/InventoryView';
import { FixedAssetsView } from './components/assets/FixedAssetsView';
import { TaxView } from './components/tax/TaxView';
import { BranchUserView } from './components/branches/BranchUserView';

function AppContent() {
  const [activeTab, setActiveTab] = useState<string>('dashboard');
  const [quickTransactionOpen, setQuickTransactionOpen] = useState(false);

  const { products, eFakturs, activeBranchId } = useApp();

  const lowStockCount = products.filter(p => {
    const total = activeBranchId === 'all'
      ? Object.values(p.stocksByBranch).reduce((a, b) => a + b, 0)
      : (p.stocksByBranch[activeBranchId] || 0);
    return total <= p.minStockAlert;
  }).length;

  const pendingEfakturCount = eFakturs.filter(ef => ef.statusDjp === 'siap_upload').length;

  const handleOpenNewTransaction = () => {
    setActiveTab('transactions');
  };

  return (
    <div className="min-h-screen bg-slate-50 flex flex-col text-slate-900 font-sans">
      {/* Top Header */}
      <Header
        activeTab={activeTab}
        setActiveTab={setActiveTab}
        onOpenNewTransaction={handleOpenNewTransaction}
      />

      {/* Main Workspace: Sidebar + Viewport */}
      <div className="flex-1 max-w-7xl w-full mx-auto flex">
        {/* Sidebar Navigation */}
        <Sidebar
          activeTab={activeTab}
          setActiveTab={setActiveTab}
          lowStockCount={lowStockCount}
          pendingEfakturCount={pendingEfakturCount}
        />

        {/* Main Content Viewport */}
        <main className="flex-1 p-4 sm:p-6 lg:p-8 overflow-y-auto">
          {activeTab === 'dashboard' && (
            <DashboardView onNavigateToTab={setActiveTab} />
          )}
          {activeTab === 'transactions' && (
            <TransactionsView />
          )}
          {activeTab === 'journal' && (
            <JournalView />
          )}
          {activeTab === 'reports' && (
            <FinancialReportsView />
          )}
          {activeTab === 'inventory' && (
            <InventoryView />
          )}
          {activeTab === 'assets' && (
            <FixedAssetsView />
          )}
          {activeTab === 'tax' && (
            <TaxView />
          )}
          {activeTab === 'branches' && (
            <BranchUserView />
          )}
        </main>
      </div>
    </div>
  );
}

export default function App() {
  return (
    <AppProvider>
      <AppContent />
    </AppProvider>
  );
}
